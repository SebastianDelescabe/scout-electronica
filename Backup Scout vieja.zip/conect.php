<?
	$Servidor = "localhost";
	$Usuario = "scoutele_ago901";
	$Password = "L8ZCFw63";
	$BaseDeDatos = "scoutele_15agosto";
	$conexion=mysql_connect($Servidor,$Usuario,$Password) or die
 ("Error: El servidor no puede conectar con la base de datos");
	$descriptor=mysql_select_db($BaseDeDatos,$conexion);
?>

