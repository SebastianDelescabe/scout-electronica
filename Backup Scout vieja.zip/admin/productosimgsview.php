<?php
define("EW_PAGE_ID", "view", TRUE); // Page ID
define("EW_TABLE_NAME", 'productosimgs', TRUE);
?>
<?php 
session_start(); // Initialize session data
ob_start(); // Turn on output buffering
?>
<?php include "ewcfg50.php" ?>
<?php include "ewmysql50.php" ?>
<?php include "phpfn50.php" ?>
<?php include "productosimgsinfo.php" ?>
<?php include "userfn50.php" ?>
<?php include "claveinfo.php" ?>
<?php
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT"); // Date in the past
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT"); // Always modified
header("Cache-Control: private, no-store, no-cache, must-revalidate"); // HTTP/1.1 
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache"); // HTTP/1.0
?>
<?php

// Open connection to the database
$conn = ew_Connect();
?>
<?php
$Security = new cAdvancedSecurity();
?>
<?php
if (!$Security->IsLoggedIn()) $Security->AutoLogin();
if (!$Security->IsLoggedIn()) {
	$Security->SaveLastUrl();
	Page_Terminate("login.php");
}
?>
<?php

// Common page loading event (in userfn*.php)
Page_Loading();
?>
<?php

// Page load event, used in current page
Page_Load();
?>
<?php
$productosimgs->Export = @$_GET["export"]; // Get export parameter
$sExport = $productosimgs->Export; // Get export parameter, used in header
$sExportFile = $productosimgs->TableVar; // Get export file, used in header
?>
<?php

// Paging variables
$nStartRec = 0; // Start record index
$nStopRec = 0; // Stop record index
$nTotalRecs = 0; // Total number of records
$nDisplayRecs = 1;
$nRecRange = 10;

// Load current record
$bLoadCurrentRecord = FALSE;
if (@$_GET["id"] <> "") {
	$productosimgs->id->setQueryStringValue($_GET["id"]);
} else {
	$bLoadCurrentRecord = TRUE;
}

// Get action
if (@$_POST["a_view"] <> "") {
	$productosimgs->CurrentAction = $_POST["a_view"];
} else {
	$productosimgs->CurrentAction = "I"; // Display form
}
switch ($productosimgs->CurrentAction) {
	case "I": // Get a record to display
		$nStartRec = 1; // Initialize start position
		$rs = LoadRecordset(); // Load records
		$nTotalRecs = $rs->RecordCount(); // Get record count
		if ($nTotalRecs <= 0) { // No record found
			$_SESSION[EW_SESSION_MESSAGE] = "No se han encontrado registros"; // Set no record message
			Page_Terminate("productosimgslist.php"); // Return to list page
		} elseif ($bLoadCurrentRecord) { // Load current record position
			SetUpStartRec(); // Set up start record position

			// Point to current record
			if (intval($nStartRec) <= intval($nTotalRecs)) {
				$rs->Move($nStartRec-1);
			}
		} else { // Match key values
			$bMatchRecord = FALSE;
			while (!$rs->EOF) {
				if (strval($productosimgs->id->CurrentValue) == strval($rs->fields('id'))) {
					$bMatchRecord = TRUE;
					break;
				} else {
					$nStartRec++;
					$rs->MoveNext();
				}
			}
			if (!$bMatchRecord) {
				$_SESSION[EW_SESSION_MESSAGE] = "No se han encontrado registros"; // Set no record message
				Page_Terminate("productosimgslist.php"); // Return to list
			} else {
				$productosimgs->setStartRecordNumber($nStartRec); // Save record position
			}
		}
		LoadRowValues($rs); // Load row values
}

// Set return url
$productosimgs->setReturnUrl("productosimgsview.php");

// Render row
$productosimgs->RowType = EW_ROWTYPE_VIEW;
RenderRow();
?>
<?php include "header.php" ?>
<script type="text/javascript">
<!--
var EW_PAGE_ID = "view"; // Page id

//-->
</script>
<script language="JavaScript" type="text/javascript">
<!--

// Write your client script here, no need to add script tags.
// To include another .js script, use:
// ew_ClientScriptInclude("my_javascript.js"); 
//-->

</script>
<p><span class="phpmaker">Ver TABLA: Productos Imgs
<br><br>
<a href="productosimgslist.php">Volver a la lista</a>&nbsp;
<?php if ($Security->IsLoggedIn()) { ?>
<a href="productosimgsadd.php">Agregar</a>&nbsp;
<?php } ?>
<?php if ($Security->IsLoggedIn()) { ?>
<a href="<?php echo $productosimgs->EditUrl() ?>">Editar</a>&nbsp;
<?php } ?>
<?php if ($Security->IsLoggedIn()) { ?>
<a href="<?php echo $productosimgs->CopyUrl() ?>">Copiar</a>&nbsp;
<?php } ?>
<?php if ($Security->IsLoggedIn()) { ?>
<a onclick="return ew_Confirm('quiere borrar este item?');" href="<?php echo $productosimgs->DeleteUrl() ?>">Borrar</a>&nbsp;
<?php } ?>
</span>
</p>
<?php
if (@$_SESSION[EW_SESSION_MESSAGE] <> "") {
?>
<p><span class="ewmsg"><?php echo $_SESSION[EW_SESSION_MESSAGE] ?></span></p>
<?php
	$_SESSION[EW_SESSION_MESSAGE] = ""; // Clear message
}
?>
<p>
<form action="productosimgsview.php" name="ewpagerform" id="ewpagerform">
<table border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td nowrap>
<?php if (!isset($Pager)) $Pager = new cPrevNextPager($nStartRec, $nDisplayRecs, $nTotalRecs) ?>
<?php if ($Pager->RecordCount > 0) { ?>
	<table border="0" cellspacing="0" cellpadding="0"><tr><td><span class="phpmaker">Pagina&nbsp;</span></td>
<!--first page button-->
	<?php if ($Pager->FirstButton->Enabled) { ?>
	<td><a href="productosimgsview.php?start=<?php echo $Pager->FirstButton->Start ?>"><img src="images/first.gif" alt="Primero" width="16" height="16" border="0"></a></td>
	<?php } else { ?>
	<td><img src="images/firstdisab.gif" alt="Primero" width="16" height="16" border="0"></td>
	<?php } ?>
<!--previous page button-->
	<?php if ($Pager->PrevButton->Enabled) { ?>
	<td><a href="productosimgsview.php?start=<?php echo $Pager->PrevButton->Start ?>"><img src="images/prev.gif" alt="Previa" width="16" height="16" border="0"></a></td>
	<?php } else { ?>
	<td><img src="images/prevdisab.gif" alt="Previa" width="16" height="16" border="0"></td>
	<?php } ?>
<!--current page number-->
	<td><input type="text" name="<?php echo EW_TABLE_PAGE_NO ?>" id="<?php echo EW_TABLE_PAGE_NO ?>" value="<?php echo $Pager->CurrentPage ?>" size="4"></td>
<!--next page button-->
	<?php if ($Pager->NextButton->Enabled) { ?>
	<td><a href="productosimgsview.php?start=<?php echo $Pager->NextButton->Start ?>"><img src="images/next.gif" alt="Siguiente" width="16" height="16" border="0"></a></td>	
	<?php } else { ?>
	<td><img src="images/nextdisab.gif" alt="Siguiente" width="16" height="16" border="0"></td>
	<?php } ?>
<!--last page button-->
	<?php if ($Pager->LastButton->Enabled) { ?>
	<td><a href="productosimgsview.php?start=<?php echo $Pager->LastButton->Start ?>"><img src="images/last.gif" alt="Ultimo" width="16" height="16" border="0"></a></td>	
	<?php } else { ?>
	<td><img src="images/lastdisab.gif" alt="Ultimo" width="16" height="16" border="0"></td>
	<?php } ?>
	<td><span class="phpmaker">&nbsp;de <?php echo $Pager->PageCount ?></span></td>
	</tr></table>
	<span class="phpmaker">Registros <?php echo $Pager->FromIndex ?> para <?php echo $Pager->ToIndex ?> de <?php echo $Pager->RecordCount ?></span>
<?php } else { ?>
	<?php if ($sSrchWhere == "0=101") { ?>
	<span class="phpmaker">criterio de busqueda</span>
	<?php } else { ?>
	<span class="phpmaker">No se han encontrado registros</span>
	<?php } ?>
<?php } ?>
		</td>
	</tr>
</table>
</form>
<form>
<table class="ewTable">
	<tr class="ewTableRow">
		<td class="ewTableHeader">id</td>
		<td<?php echo $productosimgs->id->CellAttributes() ?>>
<div<?php echo $productosimgs->id->ViewAttributes() ?>><?php echo $productosimgs->id->ViewValue ?></div>
</td>
	</tr>
	<tr class="ewTableAltRow">
		<td class="ewTableHeader">producto</td>
		<td<?php echo $productosimgs->producto->CellAttributes() ?>>
<div<?php echo $productosimgs->producto->ViewAttributes() ?>><?php echo $productosimgs->producto->ViewValue ?></div>
</td>
	</tr>
	<tr class="ewTableRow">
		<td class="ewTableHeader">imagen</td>
		<td<?php echo $productosimgs->imagen->CellAttributes() ?>>
<?php if ($productosimgs->imagen->HrefValue <> "") { ?>
<?php if (!is_null($productosimgs->imagen->Upload->DbValue)) { ?>
<a href="<?php echo $productosimgs->imagen->HrefValue ?>" target="_blank"><img src="<?php echo ew_UploadPathEx(FALSE, "../imgs/") . $productosimgs->imagen->Upload->DbValue ?>" border=0<?php echo $productosimgs->imagen->ViewAttributes() ?>></a>
<?php } ?>
<?php } else { ?>
<?php if (!is_null($productosimgs->imagen->Upload->DbValue)) { ?>
<img src="<?php echo ew_UploadPathEx(FALSE, "../imgs/") . $productosimgs->imagen->Upload->DbValue ?>" border=0<?php echo $productosimgs->imagen->ViewAttributes() ?>>
<?php } ?>
<?php } ?>
</td>
	</tr>
	<tr class="ewTableAltRow">
		<td class="ewTableHeader">titulo</td>
		<td<?php echo $productosimgs->titulo->CellAttributes() ?>>
<div<?php echo $productosimgs->titulo->ViewAttributes() ?>><?php echo $productosimgs->titulo->ViewValue ?></div>
</td>
	</tr>
</table>
</form>
<form action="productosimgsview.php" name="ewpagerform" id="ewpagerform">
<table border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td nowrap>
<?php if (!isset($Pager)) $Pager = new cPrevNextPager($nStartRec, $nDisplayRecs, $nTotalRecs) ?>
<?php if ($Pager->RecordCount > 0) { ?>
	<table border="0" cellspacing="0" cellpadding="0"><tr><td><span class="phpmaker">Pagina&nbsp;</span></td>
<!--first page button-->
	<?php if ($Pager->FirstButton->Enabled) { ?>
	<td><a href="productosimgsview.php?start=<?php echo $Pager->FirstButton->Start ?>"><img src="images/first.gif" alt="Primero" width="16" height="16" border="0"></a></td>
	<?php } else { ?>
	<td><img src="images/firstdisab.gif" alt="Primero" width="16" height="16" border="0"></td>
	<?php } ?>
<!--previous page button-->
	<?php if ($Pager->PrevButton->Enabled) { ?>
	<td><a href="productosimgsview.php?start=<?php echo $Pager->PrevButton->Start ?>"><img src="images/prev.gif" alt="Previa" width="16" height="16" border="0"></a></td>
	<?php } else { ?>
	<td><img src="images/prevdisab.gif" alt="Previa" width="16" height="16" border="0"></td>
	<?php } ?>
<!--current page number-->
	<td><input type="text" name="<?php echo EW_TABLE_PAGE_NO ?>" id="<?php echo EW_TABLE_PAGE_NO ?>" value="<?php echo $Pager->CurrentPage ?>" size="4"></td>
<!--next page button-->
	<?php if ($Pager->NextButton->Enabled) { ?>
	<td><a href="productosimgsview.php?start=<?php echo $Pager->NextButton->Start ?>"><img src="images/next.gif" alt="Siguiente" width="16" height="16" border="0"></a></td>	
	<?php } else { ?>
	<td><img src="images/nextdisab.gif" alt="Siguiente" width="16" height="16" border="0"></td>
	<?php } ?>
<!--last page button-->
	<?php if ($Pager->LastButton->Enabled) { ?>
	<td><a href="productosimgsview.php?start=<?php echo $Pager->LastButton->Start ?>"><img src="images/last.gif" alt="Ultimo" width="16" height="16" border="0"></a></td>	
	<?php } else { ?>
	<td><img src="images/lastdisab.gif" alt="Ultimo" width="16" height="16" border="0"></td>
	<?php } ?>
	<td><span class="phpmaker">&nbsp;de <?php echo $Pager->PageCount ?></span></td>
	</tr></table>
	<span class="phpmaker">Registros <?php echo $Pager->FromIndex ?> para <?php echo $Pager->ToIndex ?> de <?php echo $Pager->RecordCount ?></span>
<?php } else { ?>
	<?php if ($sSrchWhere == "0=101") { ?>
	<span class="phpmaker">criterio de busqueda</span>
	<?php } else { ?>
	<span class="phpmaker">No se han encontrado registros</span>
	<?php } ?>
<?php } ?>
		</td>
	</tr>
</table>
</form>
<p>
<script language="JavaScript" type="text/javascript">
<!--

// Write your table-specific startup script here
// document.write("page loaded");
//-->

</script>
<?php include "footer.php" ?>
<?php

// If control is passed here, simply terminate the page without redirect
Page_Terminate();

// -----------------------------------------------------------------
//  Subroutine Page_Terminate
//  - called when exit page
//  - clean up connection and objects
//  - if url specified, redirect to url, otherwise end response
function Page_Terminate($url = "") {
	global $conn;

	// Page unload event, used in current page
	Page_Unload();

	// Global page unloaded event (in userfn*.php)
	Page_Unloaded();

	 // Close Connection
	$conn->Close();

	// Go to url if specified
	if ($url <> "") {
		ob_end_clean();
		header("Location: $url");
	}
	exit();
}
?>
<?php

// Load recordset
function LoadRecordset($offset = -1, $rowcnt = -1) {
	global $conn, $productosimgs;

	// Call Recordset Selecting event
	$productosimgs->Recordset_Selecting($productosimgs->CurrentFilter);

	// Load list page sql
	$sSql = $productosimgs->SelectSQL();
	if ($offset > -1 && $rowcnt > -1) $sSql .= " LIMIT $offset, $rowcnt";

	// Load recordset
	$conn->raiseErrorFn = 'ew_ErrorFn';	
	$rs = $conn->Execute($sSql);
	$conn->raiseErrorFn = '';

	// Call Recordset Selected event
	$productosimgs->Recordset_Selected($rs);
	return $rs;
}
?>
<?php

// Load row based on key values
function LoadRow() {
	global $conn, $Security, $productosimgs;
	$sFilter = $productosimgs->SqlKeyFilter();
	if (!is_numeric($productosimgs->id->CurrentValue)) {
		return FALSE; // Invalid key, exit
	}
	$sFilter = str_replace("@id@", ew_AdjustSql($productosimgs->id->CurrentValue), $sFilter); // Replace key value

	// Call Row Selecting event
	$productosimgs->Row_Selecting($sFilter);

	// Load sql based on filter
	$productosimgs->CurrentFilter = $sFilter;
	$sSql = $productosimgs->SQL();
	if ($rs = $conn->Execute($sSql)) {
		if ($rs->EOF) {
			$LoadRow = FALSE;
		} else {
			$LoadRow = TRUE;
			$rs->MoveFirst();
			LoadRowValues($rs); // Load row values

			// Call Row Selected event
			$productosimgs->Row_Selected($rs);
		}
		$rs->Close();
	} else {
		$LoadRow = FALSE;
	}
	return $LoadRow;
}

// Load row values from recordset
function LoadRowValues(&$rs) {
	global $productosimgs;
	$productosimgs->id->setDbValue($rs->fields('id'));
	$productosimgs->producto->setDbValue($rs->fields('producto'));
	$productosimgs->imagen->Upload->DbValue = $rs->fields('imagen');
	$productosimgs->titulo->setDbValue($rs->fields('titulo'));
}
?>
<?php

// Render row values based on field settings
function RenderRow() {
	global $conn, $Security, $productosimgs;

	// Call Row Rendering event
	$productosimgs->Row_Rendering();

	// Common render codes for all row types
	// id

	$productosimgs->id->CellCssStyle = "";
	$productosimgs->id->CellCssClass = "";

	// producto
	$productosimgs->producto->CellCssStyle = "";
	$productosimgs->producto->CellCssClass = "";

	// imagen
	$productosimgs->imagen->CellCssStyle = "";
	$productosimgs->imagen->CellCssClass = "";

	// titulo
	$productosimgs->titulo->CellCssStyle = "";
	$productosimgs->titulo->CellCssClass = "";
	if ($productosimgs->RowType == EW_ROWTYPE_VIEW) { // View row

		// id
		$productosimgs->id->ViewValue = $productosimgs->id->CurrentValue;
		$productosimgs->id->CssStyle = "";
		$productosimgs->id->CssClass = "";
		$productosimgs->id->ViewCustomAttributes = "";

		// producto
		if (!is_null($productosimgs->producto->CurrentValue)) {
			$sSqlWrk = "SELECT `producto` FROM `productos` WHERE `id` = " . ew_AdjustSql($productosimgs->producto->CurrentValue) . "";
			$rswrk = $conn->Execute($sSqlWrk);
			if ($rswrk) {
				if (!$rswrk->EOF) {
					$productosimgs->producto->ViewValue = $rswrk->fields('producto');
				}
				$rswrk->Close();
			} else {
				$productosimgs->producto->ViewValue = $productosimgs->producto->CurrentValue;
			}
		} else {
			$productosimgs->producto->ViewValue = NULL;
		}
		$productosimgs->producto->CssStyle = "";
		$productosimgs->producto->CssClass = "";
		$productosimgs->producto->ViewCustomAttributes = "";

		// imagen
		if (!is_null($productosimgs->imagen->Upload->DbValue)) {
			$productosimgs->imagen->ViewValue = $productosimgs->imagen->Upload->DbValue;
			$productosimgs->imagen->ImageWidth = 100;
			$productosimgs->imagen->ImageHeight = 100;
			$productosimgs->imagen->ImageAlt = "";
		} else {
			$productosimgs->imagen->ViewValue = "";
		}
		$productosimgs->imagen->CssStyle = "";
		$productosimgs->imagen->CssClass = "";
		$productosimgs->imagen->ViewCustomAttributes = "";

		// titulo
		$productosimgs->titulo->ViewValue = $productosimgs->titulo->CurrentValue;
		$productosimgs->titulo->CssStyle = "";
		$productosimgs->titulo->CssClass = "";
		$productosimgs->titulo->ViewCustomAttributes = "";

		// id
		$productosimgs->id->HrefValue = "";

		// producto
		$productosimgs->producto->HrefValue = "";

		// imagen
		if (!is_null($productosimgs->imagen->Upload->DbValue)) {
			$productosimgs->imagen->HrefValue = ew_UploadPathEx(FALSE, "../imgs/") . ((!empty($productosimgs->imagen->ViewValue)) ? $productosimgs->imagen->ViewValue : $productosimgs->imagen->CurrentValue);
			if ($productosimgs->Export <> "") $productosimgs->imagen->HrefValue = ew_ConvertFullUrl($productosimgs->imagen->HrefValue);
		} else {
			$productosimgs->imagen->HrefValue = "";
		}

		// titulo
		$productosimgs->titulo->HrefValue = "";
	} elseif ($productosimgs->RowType == EW_ROWTYPE_ADD) { // Add row
	} elseif ($productosimgs->RowType == EW_ROWTYPE_EDIT) { // Edit row
	} elseif ($productosimgs->RowType == EW_ROWTYPE_SEARCH) { // Search row
	}

	// Call Row Rendered event
	$productosimgs->Row_Rendered();
}
?>
<?php

// Set up Starting Record parameters based on Pager Navigation
function SetUpStartRec() {
	global $nDisplayRecs, $nStartRec, $nTotalRecs, $nPageNo, $productosimgs;
	if ($nDisplayRecs == 0) return;

	// Check for a START parameter
	if (@$_GET[EW_TABLE_START_REC] <> "") {
		$nStartRec = $_GET[EW_TABLE_START_REC];
		$productosimgs->setStartRecordNumber($nStartRec);
	} elseif (@$_GET[EW_TABLE_PAGE_NO] <> "") {
		$nPageNo = $_GET[EW_TABLE_PAGE_NO];
		if (is_numeric($nPageNo)) {
			$nStartRec = ($nPageNo-1)*$nDisplayRecs+1;
			if ($nStartRec <= 0) {
				$nStartRec = 1;
			} elseif ($nStartRec >= intval(($nTotalRecs-1)/$nDisplayRecs)*$nDisplayRecs+1) {
				$nStartRec = intval(($nTotalRecs-1)/$nDisplayRecs)*$nDisplayRecs+1;
			}
			$productosimgs->setStartRecordNumber($nStartRec);
		} else {
			$nStartRec = $productosimgs->getStartRecordNumber();
		}
	} else {
		$nStartRec = $productosimgs->getStartRecordNumber();
	}

	// Check if correct start record counter
	if (!is_numeric($nStartRec) || $nStartRec == "") { // Avoid invalid start record counter
		$nStartRec = 1; // Reset start record counter
		$productosimgs->setStartRecordNumber($nStartRec);
	} elseif (intval($nStartRec) > intval($nTotalRecs)) { // Avoid starting record > total records
		$nStartRec = intval(($nTotalRecs-1)/$nDisplayRecs)*$nDisplayRecs+1; // Point to last page first record
		$productosimgs->setStartRecordNumber($nStartRec);
	} elseif (($nStartRec-1) % $nDisplayRecs <> 0) {
		$nStartRec = intval(($nStartRec-1)/$nDisplayRecs)*$nDisplayRecs+1; // Point to page boundary
		$productosimgs->setStartRecordNumber($nStartRec);
	}
}
?>
<?php

// Page Load event
function Page_Load() {

	//echo "Page Load";
}

// Page Unload event
function Page_Unload() {

	//echo "Page Unload";
}
?>
