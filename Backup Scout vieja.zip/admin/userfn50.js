
// Global user functions
