<?php
define("EW_PAGE_ID", "list", TRUE); // Page ID
define("EW_TABLE_NAME", 'productosimgs', TRUE);
?>
<?php 
session_start(); // Initialize session data
ob_start(); // Turn on output buffering
?>
<?php include "ewcfg50.php" ?>
<?php include "ewmysql50.php" ?>
<?php include "phpfn50.php" ?>
<?php include "productosimgsinfo.php" ?>
<?php include "userfn50.php" ?>
<?php include "claveinfo.php" ?>
<?php
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT"); // Date in the past
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT"); // Always modified
header("Cache-Control: private, no-store, no-cache, must-revalidate"); // HTTP/1.1 
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache"); // HTTP/1.0
?>
<?php

// Open connection to the database
$conn = ew_Connect();
?>
<?php
$Security = new cAdvancedSecurity();
?>
<?php
if (!$Security->IsLoggedIn()) $Security->AutoLogin();
if (!$Security->IsLoggedIn()) {
	$Security->SaveLastUrl();
	Page_Terminate("login.php");
}
?>
<?php

// Common page loading event (in userfn*.php)
Page_Loading();
?>
<?php

// Page load event, used in current page
Page_Load();
?>
<?php
$productosimgs->Export = @$_GET["export"]; // Get export parameter
$sExport = $productosimgs->Export; // Get export parameter, used in header
$sExportFile = $productosimgs->TableVar; // Get export file, used in header
?>
<?php
?>
<?php

// Paging variables
$nStartRec = 0; // Start record index
$nStopRec = 0; // Stop record index
$nTotalRecs = 0; // Total number of records
$nDisplayRecs = 30;
$nRecRange = 10;
$nRecCount = 0; // Record count

// Search filters
$sSrchAdvanced = ""; // Advanced search filter
$sSrchBasic = ""; // Basic search filter
$sSrchWhere = ""; // Search where clause
$sFilter = "";
$sDeleteConfirmMsg = "Quiere borrar los items seleccionados?"; // Delete confirm message

// Master/Detail
$sDbMasterFilter = ""; // Master filter
$sDbDetailFilter = ""; // Detail filter
$sSqlMaster = ""; // Sql for master record

// Handle reset command
ResetCmd();

// Get search criteria for advanced search
$sSrchAdvanced = AdvancedSearchWhere();

// Get basic search criteria
$sSrchBasic = BasicSearchWhere();

// Build search criteria
if ($sSrchAdvanced <> "") {
	if ($sSrchWhere <> "") $sSrchWhere .= " AND ";
	$sSrchWhere .= "(" . $sSrchAdvanced . ")";
}
if ($sSrchBasic <> "") {
	if ($sSrchWhere <> "") $sSrchWhere .= " AND ";
	$sSrchWhere .= "(" . $sSrchBasic . ")";
}

// Save search criteria
if ($sSrchWhere <> "") {
	if ($sSrchBasic == "") ResetBasicSearchParms();
	if ($sSrchAdvanced == "") ResetAdvancedSearchParms();
	$productosimgs->setSearchWhere($sSrchWhere); // Save to Session
	$nStartRec = 1; // Reset start record counter
	$productosimgs->setStartRecordNumber($nStartRec);
} else {
	RestoreSearchParms();
}

// Build filter
$sFilter = "";
if ($sDbDetailFilter <> "") {
	if ($sFilter <> "") $sFilter .= " AND ";
	$sFilter .= "(" . $sDbDetailFilter . ")";
}
if ($sSrchWhere <> "") {
	if ($sFilter <> "") $sFilter .= " AND ";
	$sFilter .= "(" . $sSrchWhere . ")";
}

// Set up filter in Session
$productosimgs->setSessionWhere($sFilter);
$productosimgs->CurrentFilter = "";

// Set Up Sorting Order
SetUpSortOrder();

// Set Return Url
$productosimgs->setReturnUrl("productosimgslist.php");
?>
<?php include "header.php" ?>
<?php if ($productosimgs->Export == "") { ?>
<script type="text/javascript">
<!--
var EW_PAGE_ID = "list"; // Page id

//-->
</script>
<script type="text/javascript">
<!--

function ew_ValidateForm2(fobj) {
	var infix = "";
	for (var i=0;i<fobj.elements.length;i++) {
		var elem = fobj.elements[i];
		if (elem.name.substring(0,2) == "s_" || elem.name.substring(0,3) == "sv_")
			elem.value = "";
	}
	return true;
}

//-->
</script>
<script type="text/javascript">
<!--
var firstrowoffset = 1; // First data row start at
var lastrowoffset = 0; // Last data row end at
var EW_LIST_TABLE_NAME = 'ewlistmain'; // Table name for list page
var rowclass = 'ewTableRow'; // Row class
var rowaltclass = 'ewTableAltRow'; // Row alternate class
var rowmoverclass = 'ewTableHighlightRow'; // Row mouse over class
var rowselectedclass = 'ewTableSelectRow'; // Row selected class
var roweditclass = 'ewTableEditRow'; // Row edit class

//-->
</script>
<script type="text/javascript">
<!--

// js for DHtml Editor
//-->

</script>
<script type="text/javascript">
<!--

// js for Popup Calendar
//-->

</script>
<script type="text/javascript">
<!--

function ew_SelectKey(elem) {
	var f = elem.form;	
	if (!f.elements["key_m[]"]) return;
	if (f.elements["key_m[]"][0]) {
		for (var i=0; i<f.elements["key_m[]"].length; i++)
			f.elements["key_m[]"][i].checked = elem.checked;	
	} else {
		f.elements["key_m[]"].checked = elem.checked;	
	}
	ew_ClickAll(elem);
}

function ew_Selected(f) {
	if (!f.elements["key_m[]"]) return false;
	if (f.elements["key_m[]"][0]) {
		for (var i=0; i<f.elements["key_m[]"].length; i++)
			if (f.elements["key_m[]"][i].checked) return true;
	} else {
		return f.elements["key_m[]"].checked;
	}
	return false;
}

//-->
</script>
<script language="JavaScript" type="text/javascript">
<!--

// Write your client script here, no need to add script tags.
// To include another .js script, use:
// ew_ClientScriptInclude("my_javascript.js"); 
//-->

</script>
<?php } ?>
<?php if ($productosimgs->Export == "") { ?>
<?php } ?>
<?php

// Load recordset
$bExportAll = (defined("EW_EXPORT_ALL") && $productosimgs->Export <> "");
$bSelectLimit = ($productosimgs->Export == "" && $productosimgs->SelectLimit);
if (!$bSelectLimit) $rs = LoadRecordset();
$nTotalRecs = ($bSelectLimit) ? $productosimgs->SelectRecordCount() : $rs->RecordCount();
$nStartRec = 1;
if ($nDisplayRecs <= 0) $nDisplayRecs = $nTotalRecs; // Display all records
if (!$bExportAll) SetUpStartRec(); // Set up start record position
if ($bSelectLimit) $rs = LoadRecordset($nStartRec-1, $nDisplayRecs);
?>
<p><span class="phpmaker" style="white-space: nowrap;">TABLA: Productos Imgs
</span></p>
<?php if ($productosimgs->Export == "") { ?>
<?php if ($Security->IsLoggedIn()) { ?>
<form name="fproductosimgslistsrch" id="fproductosimgslistsrch" action="productosimgslist.php" onSubmit="return ew_ValidateForm2(this);">
<?php
LoadAdvancedSearch(); // Load advanced search

// Render for search
$productosimgs->RowType = EW_ROWTYPE_SEARCH;
RenderRow();
?>
<table class="ewBasicSearch">
	<tr>
		<td><span class="phpmaker">producto</span></td>
		<td><span class="ewSearchOpr">=<input type="hidden" name="z_producto" id="z_producto" value="="></span></td>
		<td>			
			<table border="0" cellspacing="0" cellpadding="0"><tr>
				<td><span class="phpmaker">
<select id="x_producto" name="x_producto"<?php echo $productosimgs->producto->EditAttributes() ?>>
<!--option value="">Seleccione</option-->
<?php
if (is_array($productosimgs->producto->EditValue)) {
	$arwrk = $productosimgs->producto->EditValue;
	$rowswrk = count($arwrk);
	for ($rowcntwrk = 0; $rowcntwrk < $rowswrk; $rowcntwrk++) {
		$selwrk = (strval($productosimgs->producto->AdvancedSearch->SearchValue) == strval($arwrk[$rowcntwrk][0])) ? " selected" : "";	
?>
<option value="<?php echo ew_HtmlEncode($arwrk[$rowcntwrk][0]) ?>"<?php echo $selwrk ?>>
<?php echo $arwrk[$rowcntwrk][1] ?>
</option>
<?php
			}
}
?>
</select>
</span></td>
			</tr></table>			
		</td>
	</tr>
</table>
<table class="ewBasicSearch">
	<tr>
		<td><span class="phpmaker">
			<input type="text" name="<?php echo EW_TABLE_BASIC_SEARCH ?>" id="<?php echo EW_TABLE_BASIC_SEARCH ?>" size="20" value="<?php echo ew_HtmlEncode($productosimgs->getBasicSearchKeyword()) ?>">
			<input type="Submit" name="Submit" id="Submit" value="Buscar (*)">&nbsp;
			<input type="Button" name="Reset" id="Reset" value="Restablecer" onclick="ew_ClearForm(this.form);if (this.form.<?php echo EW_TABLE_BASIC_SEARCH_TYPE ?>) this.form.<?php echo EW_TABLE_BASIC_SEARCH_TYPE ?>[0].checked = true;">&nbsp;
			<a href="productosimgslist.php?cmd=reset">Mostrar todos</a>&nbsp;
		</span></td>
	</tr>
	<tr>
	<td><span class="phpmaker"><input type="radio" name="<?php echo EW_TABLE_BASIC_SEARCH_TYPE ?>" id="<?php echo EW_TABLE_BASIC_SEARCH_TYPE ?>" value="" <?php if ($productosimgs->getBasicSearchType() == "") { ?>checked<?php } ?>>Frase exacta&nbsp;&nbsp;<input type="radio" name="<?php echo EW_TABLE_BASIC_SEARCH_TYPE ?>" id="<?php echo EW_TABLE_BASIC_SEARCH_TYPE ?>" value="AND" <?php if ($productosimgs->getBasicSearchType() == "AND") { ?>checked<?php } ?>>Todas las palabras&nbsp;&nbsp;<input type="radio" name="<?php echo EW_TABLE_BASIC_SEARCH_TYPE ?>" id="<?php echo EW_TABLE_BASIC_SEARCH_TYPE ?>" value="OR" <?php if ($productosimgs->getBasicSearchType() == "OR") { ?>checked<?php } ?>>Alguna palabra</span></td>
	</tr>
</table>
</form>
<?php } ?>
<?php } ?>
<?php
if (@$_SESSION[EW_SESSION_MESSAGE] <> "") {
?>
<p><span class="ewmsg"><?php echo $_SESSION[EW_SESSION_MESSAGE] ?></span></p>
<?php
	$_SESSION[EW_SESSION_MESSAGE] = ""; // Clear message
}
?>
<?php if ($productosimgs->Export == "") { ?>
<form action="productosimgslist.php" name="ewpagerform" id="ewpagerform">
<table border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td nowrap>
<?php if (!isset($Pager)) $Pager = new cPrevNextPager($nStartRec, $nDisplayRecs, $nTotalRecs) ?>
<?php if ($Pager->RecordCount > 0) { ?>
	<table border="0" cellspacing="0" cellpadding="0"><tr><td><span class="phpmaker">Pagina&nbsp;</span></td>
<!--first page button-->
	<?php if ($Pager->FirstButton->Enabled) { ?>
	<td><a href="productosimgslist.php?start=<?php echo $Pager->FirstButton->Start ?>"><img src="images/first.gif" alt="Primero" width="16" height="16" border="0"></a></td>
	<?php } else { ?>
	<td><img src="images/firstdisab.gif" alt="Primero" width="16" height="16" border="0"></td>
	<?php } ?>
<!--previous page button-->
	<?php if ($Pager->PrevButton->Enabled) { ?>
	<td><a href="productosimgslist.php?start=<?php echo $Pager->PrevButton->Start ?>"><img src="images/prev.gif" alt="Previa" width="16" height="16" border="0"></a></td>
	<?php } else { ?>
	<td><img src="images/prevdisab.gif" alt="Previa" width="16" height="16" border="0"></td>
	<?php } ?>
<!--current page number-->
	<td><input type="text" name="<?php echo EW_TABLE_PAGE_NO ?>" id="<?php echo EW_TABLE_PAGE_NO ?>" value="<?php echo $Pager->CurrentPage ?>" size="4"></td>
<!--next page button-->
	<?php if ($Pager->NextButton->Enabled) { ?>
	<td><a href="productosimgslist.php?start=<?php echo $Pager->NextButton->Start ?>"><img src="images/next.gif" alt="Siguiente" width="16" height="16" border="0"></a></td>	
	<?php } else { ?>
	<td><img src="images/nextdisab.gif" alt="Siguiente" width="16" height="16" border="0"></td>
	<?php } ?>
<!--last page button-->
	<?php if ($Pager->LastButton->Enabled) { ?>
	<td><a href="productosimgslist.php?start=<?php echo $Pager->LastButton->Start ?>"><img src="images/last.gif" alt="Ultimo" width="16" height="16" border="0"></a></td>	
	<?php } else { ?>
	<td><img src="images/lastdisab.gif" alt="Ultimo" width="16" height="16" border="0"></td>
	<?php } ?>
	<td><span class="phpmaker">&nbsp;de <?php echo $Pager->PageCount ?></span></td>
	</tr></table>
	<span class="phpmaker">Registros <?php echo $Pager->FromIndex ?> para <?php echo $Pager->ToIndex ?> de <?php echo $Pager->RecordCount ?></span>
<?php } else { ?>
	<?php if ($sSrchWhere == "0=101") { ?>
	<span class="phpmaker">criterio de busqueda</span>
	<?php } else { ?>
	<span class="phpmaker">No se han encontrado registros</span>
	<?php } ?>
<?php } ?>
		</td>
	</tr>
</table>
</form>
<?php } ?>
<form method="post" name="fproductosimgslist" id="fproductosimgslist">
<?php if ($productosimgs->Export == "") { ?>
<table>
	<tr><td><span class="phpmaker">
<?php if ($Security->IsLoggedIn()) { ?>
<a href="productosimgsadd.php">Agregar</a>&nbsp;&nbsp;
<?php } ?>
<?php if ($nTotalRecs > 0) { ?>
<?php if ($Security->IsLoggedIn()) { ?>
<a href="" onClick="if (!ew_Selected(document.fproductosimgslist)) alert('Ning�n registro, seleccione'); else if (ew_Confirm('quiere borrar este item?')) {document.fproductosimgslist.action='productosimgsdelete.php';document.fproductosimgslist.encoding='application/x-www-form-urlencoded';document.fproductosimgslist.submit();};return false;">Borrar los registros seleccionados</a>&nbsp;&nbsp;
<?php } ?>
<?php } ?>
	</span></td></tr>
</table>
<?php } ?>
<?php if ($nTotalRecs > 0) { ?>
<table id="ewlistmain" class="ewTable">
<?php
	$OptionCnt = 0;
if ($Security->IsLoggedIn()) {
	$OptionCnt++; // view
}
if ($Security->IsLoggedIn()) {
	$OptionCnt++; // edit
}
if ($Security->IsLoggedIn()) {
	$OptionCnt++; // copy
}
if ($Security->IsLoggedIn()) {
	$OptionCnt++; // multi select
}
?>
	<!-- Table header -->
	<tr class="ewTableHeader">
		<td valign="top">
<?php if ($productosimgs->Export <> "") { ?>
id
<?php } else { ?>
	<a href="productosimgslist.php?order=<?php echo urlencode('id') ?>&ordertype=<?php echo $productosimgs->id->ReverseSort() ?>">id<?php if ($productosimgs->id->getSort() == "ASC") { ?><img src="images/sortup.gif" width="10" height="9" border="0"><?php } elseif ($productosimgs->id->getSort() == "DESC") { ?><img src="images/sortdown.gif" width="10" height="9" border="0"><?php } ?></a>
<?php } ?>
		</td>
		<td valign="top">
<?php if ($productosimgs->Export <> "") { ?>
producto
<?php } else { ?>
	<a href="productosimgslist.php?order=<?php echo urlencode('producto') ?>&ordertype=<?php echo $productosimgs->producto->ReverseSort() ?>">producto<?php if ($productosimgs->producto->getSort() == "ASC") { ?><img src="images/sortup.gif" width="10" height="9" border="0"><?php } elseif ($productosimgs->producto->getSort() == "DESC") { ?><img src="images/sortdown.gif" width="10" height="9" border="0"><?php } ?></a>
<?php } ?>
		</td>
		<td valign="top">
<?php if ($productosimgs->Export <> "") { ?>
imagen
<?php } else { ?>
	<a href="productosimgslist.php?order=<?php echo urlencode('imagen') ?>&ordertype=<?php echo $productosimgs->imagen->ReverseSort() ?>">imagen&nbsp;(*)<?php if ($productosimgs->imagen->getSort() == "ASC") { ?><img src="images/sortup.gif" width="10" height="9" border="0"><?php } elseif ($productosimgs->imagen->getSort() == "DESC") { ?><img src="images/sortdown.gif" width="10" height="9" border="0"><?php } ?></a>
<?php } ?>
		</td>
		<td valign="top">
<?php if ($productosimgs->Export <> "") { ?>
titulo
<?php } else { ?>
	<a href="productosimgslist.php?order=<?php echo urlencode('titulo') ?>&ordertype=<?php echo $productosimgs->titulo->ReverseSort() ?>">titulo&nbsp;(*)<?php if ($productosimgs->titulo->getSort() == "ASC") { ?><img src="images/sortup.gif" width="10" height="9" border="0"><?php } elseif ($productosimgs->titulo->getSort() == "DESC") { ?><img src="images/sortdown.gif" width="10" height="9" border="0"><?php } ?></a>
<?php } ?>
		</td>
<?php if ($productosimgs->Export == "") { ?>
<?php if ($Security->IsLoggedIn()) { ?>
<td nowrap>&nbsp;</td>
<?php } ?>
<?php if ($Security->IsLoggedIn()) { ?>
<td nowrap>&nbsp;</td>
<?php } ?>
<?php if ($Security->IsLoggedIn()) { ?>
<td nowrap>&nbsp;</td>
<?php } ?>
<?php if ($Security->IsLoggedIn()) { ?>
<td nowrap><input type="checkbox" class="phpmaker" onClick="ew_SelectKey(this);"></td>
<?php } ?>
<?php } ?>
	</tr>
<?php
if (defined("EW_EXPORT_ALL") && $productosimgs->Export <> "") {
	$nStopRec = $nTotalRecs;
} else {
	$nStopRec = $nStartRec + $nDisplayRecs - 1; // Set the last record to display
}
$nRecCount = $nStartRec - 1;
if (!$rs->EOF) {
	$rs->MoveFirst();
	if (!$productosimgs->SelectLimit) $rs->Move($nStartRec - 1); // Move to first record directly
}
$RowCnt = 0;
while (!$rs->EOF && $nRecCount < $nStopRec) {
	$nRecCount++;
	if (intval($nRecCount) >= intval($nStartRec)) {
		$RowCnt++;

	// Init row class and style
	$productosimgs->CssClass = "ewTableRow";
	$productosimgs->CssStyle = "";

	// Init row event
	$productosimgs->RowClientEvents = "onmouseover='ew_MouseOver(this);' onmouseout='ew_MouseOut(this);' onclick='ew_Click(this);'";

	// Display alternate color for rows
	if ($RowCnt % 2 == 0) {
		$productosimgs->CssClass = "ewTableAltRow";
	}
	LoadRowValues($rs); // Load row values
	$productosimgs->RowType = EW_ROWTYPE_VIEW; // Render view
	RenderRow();
?>
	<!-- Table body -->
	<tr<?php echo $productosimgs->DisplayAttributes() ?>>
		<!-- id -->
		<td<?php echo $productosimgs->id->CellAttributes() ?>>
<div<?php echo $productosimgs->id->ViewAttributes() ?>><?php echo $productosimgs->id->ViewValue ?></div>
</td>
		<!-- producto -->
		<td<?php echo $productosimgs->producto->CellAttributes() ?>>
<div<?php echo $productosimgs->producto->ViewAttributes() ?>><?php echo $productosimgs->producto->ViewValue ?></div>
</td>
		<!-- imagen -->
		<td<?php echo $productosimgs->imagen->CellAttributes() ?>>
<?php if ($productosimgs->imagen->HrefValue <> "") { ?>
<?php if (!is_null($productosimgs->imagen->Upload->DbValue)) { ?>
<a href="<?php echo $productosimgs->imagen->HrefValue ?>" target="_blank"><img src="<?php echo ew_UploadPathEx(FALSE, "../imgs/") . $productosimgs->imagen->Upload->DbValue ?>" border=0<?php echo $productosimgs->imagen->ViewAttributes() ?>></a>
<?php } ?>
<?php } else { ?>
<?php if (!is_null($productosimgs->imagen->Upload->DbValue)) { ?>
<img src="<?php echo ew_UploadPathEx(FALSE, "../imgs/") . $productosimgs->imagen->Upload->DbValue ?>" border=0<?php echo $productosimgs->imagen->ViewAttributes() ?>>
<?php } ?>
<?php } ?>
</td>
		<!-- titulo -->
		<td<?php echo $productosimgs->titulo->CellAttributes() ?>>
<div<?php echo $productosimgs->titulo->ViewAttributes() ?>><?php echo $productosimgs->titulo->ViewValue ?></div>
</td>
<?php if ($productosimgs->Export == "") { ?>
<?php if ($Security->IsLoggedIn()) { ?>
<td nowrap><span class="phpmaker">
<a href="<?php echo $productosimgs->ViewUrl() ?>">Ver</a>
</span></td>
<?php } ?>
<?php if ($Security->IsLoggedIn()) { ?>
<td nowrap><span class="phpmaker">
<a href="<?php echo $productosimgs->EditUrl() ?>">Editar</a>
</span></td>
<?php } ?>
<?php if ($Security->IsLoggedIn()) { ?>
<td nowrap><span class="phpmaker">
<a href="<?php echo $productosimgs->CopyUrl() ?>">Copiar</a>
</span></td>
<?php } ?>
<?php if ($Security->IsLoggedIn()) { ?>
<td nowrap><span class="phpmaker">
<input type="checkbox" name="key_m[]" id="key_m[]" value="<?php echo ew_HtmlEncode($productosimgs->id->CurrentValue) ?>" class="phpmaker" onclick='ew_ClickMultiCheckbox(this);'>
</span></td>
<?php } ?>
<?php } ?>
	</tr>
<?php
	}
	$rs->MoveNext();
}
?>
</table>
<?php if ($productosimgs->Export == "") { ?>
<table>
	<tr><td><span class="phpmaker">
<?php if ($Security->IsLoggedIn()) { ?>
<a href="productosimgsadd.php">Agregar</a>&nbsp;&nbsp;
<?php } ?>
<?php if ($nTotalRecs > 0) { ?>
<?php if ($Security->IsLoggedIn()) { ?>
<a href="" onClick="if (!ew_Selected(document.fproductosimgslist)) alert('Ning�n registro, seleccione'); else if (ew_Confirm('quiere borrar este item?')) {document.fproductosimgslist.action='productosimgsdelete.php';document.fproductosimgslist.encoding='application/x-www-form-urlencoded';document.fproductosimgslist.submit();};return false;">Borrar los registros seleccionados</a>&nbsp;&nbsp;
<?php } ?>
<?php } ?>
	</span></td></tr>
</table>
<?php } ?>
<?php } ?>
</form>
<?php

// Close recordset and connection
if ($rs) $rs->Close();
?>
<?php if ($productosimgs->Export == "") { ?>
<form action="productosimgslist.php" name="ewpagerform" id="ewpagerform">
<table border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td nowrap>
<?php if (!isset($Pager)) $Pager = new cPrevNextPager($nStartRec, $nDisplayRecs, $nTotalRecs) ?>
<?php if ($Pager->RecordCount > 0) { ?>
	<table border="0" cellspacing="0" cellpadding="0"><tr><td><span class="phpmaker">Pagina&nbsp;</span></td>
<!--first page button-->
	<?php if ($Pager->FirstButton->Enabled) { ?>
	<td><a href="productosimgslist.php?start=<?php echo $Pager->FirstButton->Start ?>"><img src="images/first.gif" alt="Primero" width="16" height="16" border="0"></a></td>
	<?php } else { ?>
	<td><img src="images/firstdisab.gif" alt="Primero" width="16" height="16" border="0"></td>
	<?php } ?>
<!--previous page button-->
	<?php if ($Pager->PrevButton->Enabled) { ?>
	<td><a href="productosimgslist.php?start=<?php echo $Pager->PrevButton->Start ?>"><img src="images/prev.gif" alt="Previa" width="16" height="16" border="0"></a></td>
	<?php } else { ?>
	<td><img src="images/prevdisab.gif" alt="Previa" width="16" height="16" border="0"></td>
	<?php } ?>
<!--current page number-->
	<td><input type="text" name="<?php echo EW_TABLE_PAGE_NO ?>" id="<?php echo EW_TABLE_PAGE_NO ?>" value="<?php echo $Pager->CurrentPage ?>" size="4"></td>
<!--next page button-->
	<?php if ($Pager->NextButton->Enabled) { ?>
	<td><a href="productosimgslist.php?start=<?php echo $Pager->NextButton->Start ?>"><img src="images/next.gif" alt="Siguiente" width="16" height="16" border="0"></a></td>	
	<?php } else { ?>
	<td><img src="images/nextdisab.gif" alt="Siguiente" width="16" height="16" border="0"></td>
	<?php } ?>
<!--last page button-->
	<?php if ($Pager->LastButton->Enabled) { ?>
	<td><a href="productosimgslist.php?start=<?php echo $Pager->LastButton->Start ?>"><img src="images/last.gif" alt="Ultimo" width="16" height="16" border="0"></a></td>	
	<?php } else { ?>
	<td><img src="images/lastdisab.gif" alt="Ultimo" width="16" height="16" border="0"></td>
	<?php } ?>
	<td><span class="phpmaker">&nbsp;de <?php echo $Pager->PageCount ?></span></td>
	</tr></table>
	<span class="phpmaker">Registros <?php echo $Pager->FromIndex ?> para <?php echo $Pager->ToIndex ?> de <?php echo $Pager->RecordCount ?></span>
<?php } else { ?>
	<?php if ($sSrchWhere == "0=101") { ?>
	<span class="phpmaker">criterio de busqueda</span>
	<?php } else { ?>
	<span class="phpmaker">No se han encontrado registros</span>
	<?php } ?>
<?php } ?>
		</td>
	</tr>
</table>
</form>
<?php } ?>
<?php if ($productosimgs->Export == "") { ?>
<?php } ?>
<?php if ($productosimgs->Export == "") { ?>
<script language="JavaScript" type="text/javascript">
<!--

// Write your table-specific startup script here
// document.write("page loaded");
//-->

</script>
<?php } ?>
<?php include "footer.php" ?>
<?php

// If control is passed here, simply terminate the page without redirect
Page_Terminate();

// -----------------------------------------------------------------
//  Subroutine Page_Terminate
//  - called when exit page
//  - clean up connection and objects
//  - if url specified, redirect to url, otherwise end response
function Page_Terminate($url = "") {
	global $conn;

	// Page unload event, used in current page
	Page_Unload();

	// Global page unloaded event (in userfn*.php)
	Page_Unloaded();

	 // Close Connection
	$conn->Close();

	// Go to url if specified
	if ($url <> "") {
		ob_end_clean();
		header("Location: $url");
	}
	exit();
}
?>
<?php

// Return Advanced Search Where based on QueryString parameters
function AdvancedSearchWhere() {
	global $Security, $productosimgs;
	$sWhere = "";

	// Field id
	BuildSearchSql($sWhere, $productosimgs->id, @$_GET["x_id"], @$_GET["z_id"], @$_GET["v_id"], @$_GET["y_id"], @$_GET["w_id"]);

	// Field producto
	BuildSearchSql($sWhere, $productosimgs->producto, @$_GET["x_producto"], @$_GET["z_producto"], @$_GET["v_producto"], @$_GET["y_producto"], @$_GET["w_producto"]);

	// Field titulo
	BuildSearchSql($sWhere, $productosimgs->titulo, @$_GET["x_titulo"], @$_GET["z_titulo"], @$_GET["v_titulo"], @$_GET["y_titulo"], @$_GET["w_titulo"]);

	//AdvancedSearchWhere = sWhere
	// Set up search parm

	if ($sWhere <> "") {

		// Field id
		SetSearchParm($productosimgs->id, @$_GET["x_id"], @$_GET["z_id"], @$_GET["v_id"], @$_GET["y_id"], @$_GET["w_id"]);

		// Field producto
		SetSearchParm($productosimgs->producto, @$_GET["x_producto"], @$_GET["z_producto"], @$_GET["v_producto"], @$_GET["y_producto"], @$_GET["w_producto"]);

		// Field titulo
		SetSearchParm($productosimgs->titulo, @$_GET["x_titulo"], @$_GET["z_titulo"], @$_GET["v_titulo"], @$_GET["y_titulo"], @$_GET["w_titulo"]);
	}
	return $sWhere;
}

// Build search sql
function BuildSearchSql(&$Where, &$Fld, $FldVal, $FldOpr, $FldCond, $FldVal2, $FldOpr2) {
	$sWrk = "";
	$FldParm = substr($Fld->FldVar, 2);
	$FldVal = ew_StripSlashes($FldVal);
	if (is_array($FldVal)) $FldVal = implode(",", $FldVal);
	$FldVal2 = ew_StripSlashes($FldVal2);
	if (is_array($FldVal2)) $FldVal2 = implode(",", $FldVal2);
	$FldOpr = strtoupper(trim($FldOpr));
	if ($FldOpr == "") $FldOpr = "=";
	$FldOpr2 = strtoupper(trim($FldOpr2));
	if ($FldOpr2 == "") $FldOpr2 = "=";
	if ($Fld->FldDataType == EW_DATATYPE_BOOLEAN) {
		if ($FldVal <> "") $FldVal = ($FldVal == "1") ? $Fld->TrueValue : $Fld->FalseValue;
		if ($FldVal2 <> "") $FldVal2 = ($FldVal2 == "1") ? $Fld->TrueValue : $Fld->FalseValue;
	} elseif ($Fld->FldDataType == EW_DATATYPE_DATE) {
		if ($FldVal <> "") $FldVal = ew_UnFormatDateTime($FldVal, $Fld->FldDateTimeFormat);
		if ($FldVal2 <> "") $FldVal2 = ew_UnFormatDateTime($FldVal2, $Fld->FldDateTimeFormat);
	}
	if ($FldOpr == "BETWEEN") {
		$IsValidValue = (($Fld->FldDataType <> EW_DATATYPE_NUMBER) ||
			($Fld->FldDataType == EW_DATATYPE_NUMBER && is_numeric($FldVal) && is_numeric($FldVal2)));
		if ($FldVal <> "" && $FldVal2 <> "" && $IsValidValue) {
			$sWrk = $Fld->FldExpression . " BETWEEN " . ew_QuotedValue($FldVal, $Fld->FldDataType) .
				" AND " . ew_QuotedValue($FldVal2, $Fld->FldDataType);
		}
	} elseif ($FldOpr == "IS NULL" || $FldOpr == "IS NOT NULL") {
		$sWrk = $Fld->FldExpression . " " . $FldOpr;
	} else {
		$IsValidValue = (($Fld->FldDataType <> EW_DATATYPE_NUMBER) ||
			($Fld->FldDataType == EW_DATATYPE_NUMBER && is_numeric($FldVal)));
		if ($FldVal <> "" && $IsValidValue && ew_IsValidOpr($FldOpr, $Fld->FldDataType)) {
			$sWrk = $Fld->FldExpression . SearchString($FldOpr, $FldVal, $Fld->FldDataType);
		}
		$IsValidValue = (($Fld->FldDataType <> EW_DATATYPE_NUMBER) ||
			($Fld->FldDataType == EW_DATATYPE_NUMBER && is_numeric($FldVal2)));
		if ($FldVal2 <> "" && $IsValidValue && ew_IsValidOpr($FldOpr2, $Fld->FldDataType)) {
			if ($sWrk <> "") {
				$sWrk .= " " . (($FldCond=="OR")?"OR":"AND") . " ";
			}
			$sWrk .= $Fld->FldExpression . SearchString($FldOpr2, $FldVal2, $Fld->FldDataType);
		}
	}
	if ($sWrk <> "") {
		if ($Where <> "") $Where .= " AND ";
		$Where .= "(" . $sWrk . ")";
	}
}

// Return search string
function SearchString($FldOpr, $FldVal, $FldType) {
	if ($FldOpr == "LIKE" || $FldOpr == "NOT LIKE") {
		return " " . $FldOpr . " " . ew_QuotedValue("%" . $FldVal . "%", $FldType);
	} elseif ($FldOpr == "STARTS WITH") {
		return " LIKE " . ew_QuotedValue($FldVal . "%", $FldType);
	} else {
		return " " . $FldOpr . " " . ew_QuotedValue($FldVal, $FldType);
	}
}

// Set search parm
function SetSearchParm($Fld, $FldVal, $FldOpr, $FldCond, $FldVal2, $FldOpr2) {
	global $productosimgs;
	$FldParm = substr($Fld->FldVar, 2);
	$FldVal = ew_StripSlashes($FldVal);
	if (is_array($FldVal)) $FldVal = implode(",", $FldVal);
	$FldVal2 = ew_StripSlashes($FldVal2);
	if (is_array($FldVal2)) $FldVal2 = implode(",", $FldVal2);
	$productosimgs->setAdvancedSearch("x_" . $FldParm, $FldVal);
	$productosimgs->setAdvancedSearch("z_" . $FldParm, $FldOpr);
	$productosimgs->setAdvancedSearch("v_" . $FldParm, $FldCond);
	$productosimgs->setAdvancedSearch("y_" . $FldParm, $FldVal2);
	$productosimgs->setAdvancedSearch("w_" . $FldParm, $FldOpr2);
}

// Return Basic Search sql
function BasicSearchSQL($Keyword) {
	$sKeyword = ew_AdjustSql($Keyword);
	$sql = "";
	$sql .= "`imagen` LIKE '%" . $sKeyword . "%' OR ";
	$sql .= "`titulo` LIKE '%" . $sKeyword . "%' OR ";
	if (substr($sql, -4) == " OR ") $sql = substr($sql, 0, strlen($sql)-4);
	return $sql;
}

// Return Basic Search Where based on search keyword and type
function BasicSearchWhere() {
	global $Security, $productosimgs;
	$sSearchStr = "";
	$sSearchKeyword = ew_StripSlashes(@$_GET[EW_TABLE_BASIC_SEARCH]);
	$sSearchType = @$_GET[EW_TABLE_BASIC_SEARCH_TYPE];
	if ($sSearchKeyword <> "") {
		$sSearch = trim($sSearchKeyword);
		if ($sSearchType <> "") {
			while (strpos($sSearch, "  ") !== FALSE)
				$sSearch = str_replace("  ", " ", $sSearch);
			$arKeyword = explode(" ", trim($sSearch));
			foreach ($arKeyword as $sKeyword) {
				if ($sSearchStr <> "") $sSearchStr .= " " . $sSearchType . " ";
				$sSearchStr .= "(" . BasicSearchSQL($sKeyword) . ")";
			}
		} else {
			$sSearchStr = BasicSearchSQL($sSearch);
		}
	}
	if ($sSearchKeyword <> "") {
		$productosimgs->setBasicSearchKeyword($sSearchKeyword);
		$productosimgs->setBasicSearchType($sSearchType);
	}
	return $sSearchStr;
}

// Clear all search parameters
function ResetSearchParms() {

	// Clear search where
	global $productosimgs;
	$sSrchWhere = "";
	$productosimgs->setSearchWhere($sSrchWhere);

	// Clear basic search parameters
	ResetBasicSearchParms();

	// Clear advanced search parameters
	ResetAdvancedSearchParms();
}

// Clear all basic search parameters
function ResetBasicSearchParms() {

	// Clear basic search parameters
	global $productosimgs;
	$productosimgs->setBasicSearchKeyword("");
	$productosimgs->setBasicSearchType("");
}

// Clear all advanced search parameters
function ResetAdvancedSearchParms() {

	// Clear advanced search parameters
	global $productosimgs;
	$productosimgs->setAdvancedSearch("x_id", "");
	$productosimgs->setAdvancedSearch("x_producto", "");
	$productosimgs->setAdvancedSearch("x_titulo", "");
}

// Restore all search parameters
function RestoreSearchParms() {
	global $sSrchWhere, $productosimgs;
	$sSrchWhere = $productosimgs->getSearchWhere();

	// Restore advanced search settings
	RestoreAdvancedSearchParms();
}

// Restore all advanced search parameters
function RestoreAdvancedSearchParms() {

	// Restore advanced search parms
	global $productosimgs;
	 $productosimgs->id->AdvancedSearch->SearchValue = $productosimgs->getAdvancedSearch("x_id");
	 $productosimgs->producto->AdvancedSearch->SearchValue = $productosimgs->getAdvancedSearch("x_producto");
	 $productosimgs->titulo->AdvancedSearch->SearchValue = $productosimgs->getAdvancedSearch("x_titulo");
}

// Set up Sort parameters based on Sort Links clicked
function SetUpSortOrder() {
	global $productosimgs;

	// Check for an Order parameter
	if (@$_GET["order"] <> "") {
		$productosimgs->CurrentOrder = ew_StripSlashes(@$_GET["order"]);
		$productosimgs->CurrentOrderType = @$_GET["ordertype"];

		// Field id
		$productosimgs->UpdateSort($productosimgs->id);

		// Field producto
		$productosimgs->UpdateSort($productosimgs->producto);

		// Field imagen
		$productosimgs->UpdateSort($productosimgs->imagen);

		// Field titulo
		$productosimgs->UpdateSort($productosimgs->titulo);
		$productosimgs->setStartRecordNumber(1); // Reset start position
	}
	$sOrderBy = $productosimgs->getSessionOrderBy(); // Get order by from Session
	if ($sOrderBy == "") {
		if ($productosimgs->SqlOrderBy() <> "") {
			$sOrderBy = $productosimgs->SqlOrderBy();
			$productosimgs->setSessionOrderBy($sOrderBy);
		}
	}
}

// Reset command based on querystring parameter cmd=
// - RESET: reset search parameters
// - RESETALL: reset search & master/detail parameters
// - RESETSORT: reset sort parameters
function ResetCmd() {
	global $sDbMasterFilter, $sDbDetailFilter, $nStartRec, $sOrderBy;
	global $productosimgs;

	// Get reset cmd
	if (@$_GET["cmd"] <> "") {
		$sCmd = $_GET["cmd"];

		// Reset search criteria
		if (strtolower($sCmd) == "reset" || strtolower($sCmd) == "resetall") {
			ResetSearchParms();
		}

		// Reset Sort Criteria
		if (strtolower($sCmd) == "resetsort") {
			$sOrderBy = "";
			$productosimgs->setSessionOrderBy($sOrderBy);
			$productosimgs->id->setSort("");
			$productosimgs->producto->setSort("");
			$productosimgs->imagen->setSort("");
			$productosimgs->titulo->setSort("");
		}

		// Reset start position
		$nStartRec = 1;
		$productosimgs->setStartRecordNumber($nStartRec);
	}
}
?>
<?php

// Set up Starting Record parameters based on Pager Navigation
function SetUpStartRec() {
	global $nDisplayRecs, $nStartRec, $nTotalRecs, $nPageNo, $productosimgs;
	if ($nDisplayRecs == 0) return;

	// Check for a START parameter
	if (@$_GET[EW_TABLE_START_REC] <> "") {
		$nStartRec = $_GET[EW_TABLE_START_REC];
		$productosimgs->setStartRecordNumber($nStartRec);
	} elseif (@$_GET[EW_TABLE_PAGE_NO] <> "") {
		$nPageNo = $_GET[EW_TABLE_PAGE_NO];
		if (is_numeric($nPageNo)) {
			$nStartRec = ($nPageNo-1)*$nDisplayRecs+1;
			if ($nStartRec <= 0) {
				$nStartRec = 1;
			} elseif ($nStartRec >= intval(($nTotalRecs-1)/$nDisplayRecs)*$nDisplayRecs+1) {
				$nStartRec = intval(($nTotalRecs-1)/$nDisplayRecs)*$nDisplayRecs+1;
			}
			$productosimgs->setStartRecordNumber($nStartRec);
		} else {
			$nStartRec = $productosimgs->getStartRecordNumber();
		}
	} else {
		$nStartRec = $productosimgs->getStartRecordNumber();
	}

	// Check if correct start record counter
	if (!is_numeric($nStartRec) || $nStartRec == "") { // Avoid invalid start record counter
		$nStartRec = 1; // Reset start record counter
		$productosimgs->setStartRecordNumber($nStartRec);
	} elseif (intval($nStartRec) > intval($nTotalRecs)) { // Avoid starting record > total records
		$nStartRec = intval(($nTotalRecs-1)/$nDisplayRecs)*$nDisplayRecs+1; // Point to last page first record
		$productosimgs->setStartRecordNumber($nStartRec);
	} elseif (($nStartRec-1) % $nDisplayRecs <> 0) {
		$nStartRec = intval(($nStartRec-1)/$nDisplayRecs)*$nDisplayRecs+1; // Point to page boundary
		$productosimgs->setStartRecordNumber($nStartRec);
	}
}
?>
<?php

// Load recordset
function LoadRecordset($offset = -1, $rowcnt = -1) {
	global $conn, $productosimgs;

	// Call Recordset Selecting event
	$productosimgs->Recordset_Selecting($productosimgs->CurrentFilter);

	// Load list page sql
	$sSql = $productosimgs->SelectSQL();
	if ($offset > -1 && $rowcnt > -1) $sSql .= " LIMIT $offset, $rowcnt";

	// Load recordset
	$conn->raiseErrorFn = 'ew_ErrorFn';	
	$rs = $conn->Execute($sSql);
	$conn->raiseErrorFn = '';

	// Call Recordset Selected event
	$productosimgs->Recordset_Selected($rs);
	return $rs;
}
?>
<?php

// Load row based on key values
function LoadRow() {
	global $conn, $Security, $productosimgs;
	$sFilter = $productosimgs->SqlKeyFilter();
	if (!is_numeric($productosimgs->id->CurrentValue)) {
		return FALSE; // Invalid key, exit
	}
	$sFilter = str_replace("@id@", ew_AdjustSql($productosimgs->id->CurrentValue), $sFilter); // Replace key value

	// Call Row Selecting event
	$productosimgs->Row_Selecting($sFilter);

	// Load sql based on filter
	$productosimgs->CurrentFilter = $sFilter;
	$sSql = $productosimgs->SQL();
	if ($rs = $conn->Execute($sSql)) {
		if ($rs->EOF) {
			$LoadRow = FALSE;
		} else {
			$LoadRow = TRUE;
			$rs->MoveFirst();
			LoadRowValues($rs); // Load row values

			// Call Row Selected event
			$productosimgs->Row_Selected($rs);
		}
		$rs->Close();
	} else {
		$LoadRow = FALSE;
	}
	return $LoadRow;
}

// Load row values from recordset
function LoadRowValues(&$rs) {
	global $productosimgs;
	$productosimgs->id->setDbValue($rs->fields('id'));
	$productosimgs->producto->setDbValue($rs->fields('producto'));
	$productosimgs->imagen->Upload->DbValue = $rs->fields('imagen');
	$productosimgs->titulo->setDbValue($rs->fields('titulo'));
}
?>
<?php

// Render row values based on field settings
function RenderRow() {
	global $conn, $Security, $productosimgs;

	// Call Row Rendering event
	$productosimgs->Row_Rendering();

	// Common render codes for all row types
	// id

	$productosimgs->id->CellCssStyle = "";
	$productosimgs->id->CellCssClass = "";

	// producto
	$productosimgs->producto->CellCssStyle = "";
	$productosimgs->producto->CellCssClass = "";

	// imagen
	$productosimgs->imagen->CellCssStyle = "";
	$productosimgs->imagen->CellCssClass = "";

	// titulo
	$productosimgs->titulo->CellCssStyle = "";
	$productosimgs->titulo->CellCssClass = "";
	if ($productosimgs->RowType == EW_ROWTYPE_VIEW) { // View row

		// id
		$productosimgs->id->ViewValue = $productosimgs->id->CurrentValue;
		$productosimgs->id->CssStyle = "";
		$productosimgs->id->CssClass = "";
		$productosimgs->id->ViewCustomAttributes = "";

		// producto
		if (!is_null($productosimgs->producto->CurrentValue)) {
			$sSqlWrk = "SELECT `producto` FROM `productos` WHERE `id` = " . ew_AdjustSql($productosimgs->producto->CurrentValue) . "";
			$rswrk = $conn->Execute($sSqlWrk);
			if ($rswrk) {
				if (!$rswrk->EOF) {
					$productosimgs->producto->ViewValue = $rswrk->fields('producto');
				}
				$rswrk->Close();
			} else {
				$productosimgs->producto->ViewValue = $productosimgs->producto->CurrentValue;
			}
		} else {
			$productosimgs->producto->ViewValue = NULL;
		}
		$productosimgs->producto->CssStyle = "";
		$productosimgs->producto->CssClass = "";
		$productosimgs->producto->ViewCustomAttributes = "";

		// imagen
		if (!is_null($productosimgs->imagen->Upload->DbValue)) {
			$productosimgs->imagen->ViewValue = $productosimgs->imagen->Upload->DbValue;
			$productosimgs->imagen->ImageWidth = 100;
			$productosimgs->imagen->ImageHeight = 100;
			$productosimgs->imagen->ImageAlt = "";
		} else {
			$productosimgs->imagen->ViewValue = "";
		}
		$productosimgs->imagen->CssStyle = "";
		$productosimgs->imagen->CssClass = "";
		$productosimgs->imagen->ViewCustomAttributes = "";

		// titulo
		$productosimgs->titulo->ViewValue = $productosimgs->titulo->CurrentValue;
		$productosimgs->titulo->CssStyle = "";
		$productosimgs->titulo->CssClass = "";
		$productosimgs->titulo->ViewCustomAttributes = "";

		// id
		$productosimgs->id->HrefValue = "";

		// producto
		$productosimgs->producto->HrefValue = "";

		// imagen
		if (!is_null($productosimgs->imagen->Upload->DbValue)) {
			$productosimgs->imagen->HrefValue = ew_UploadPathEx(FALSE, "../imgs/") . ((!empty($productosimgs->imagen->ViewValue)) ? $productosimgs->imagen->ViewValue : $productosimgs->imagen->CurrentValue);
			if ($productosimgs->Export <> "") $productosimgs->imagen->HrefValue = ew_ConvertFullUrl($productosimgs->imagen->HrefValue);
		} else {
			$productosimgs->imagen->HrefValue = "";
		}

		// titulo
		$productosimgs->titulo->HrefValue = "";
	} elseif ($productosimgs->RowType == EW_ROWTYPE_ADD) { // Add row
	} elseif ($productosimgs->RowType == EW_ROWTYPE_EDIT) { // Edit row
	} elseif ($productosimgs->RowType == EW_ROWTYPE_SEARCH) { // Search row

		// producto
		$productosimgs->producto->EditCustomAttributes = "";
		$sSqlWrk = "SELECT `id`, `producto` FROM `productos`";
		$rswrk = $conn->Execute($sSqlWrk);
		$arwrk = ($rswrk) ? $rswrk->GetRows() : array();
		if ($rswrk) $rswrk->Close();
		array_unshift($arwrk, array("", "Seleccione"));
		$productosimgs->producto->EditValue = $arwrk;
	}

	// Call Row Rendered event
	$productosimgs->Row_Rendered();
}
?>
<?php

// Load advanced search
function LoadAdvancedSearch() {
	global $productosimgs;
	$productosimgs->producto->AdvancedSearch->SearchValue = $productosimgs->getAdvancedSearch("x_producto");
}
?>
<?php

// Page Load event
function Page_Load() {

	//echo "Page Load";
}

// Page Unload event
function Page_Unload() {

	//echo "Page Unload";
}
?>
