<?php
define("EW_PAGE_ID", "edit", TRUE); // Page ID
define("EW_TABLE_NAME", 'productosimgs', TRUE);
?>
<?php 
session_start(); // Initialize session data
ob_start(); // Turn on output buffering
?>
<?php include "ewcfg50.php" ?>
<?php include "ewmysql50.php" ?>
<?php include "phpfn50.php" ?>
<?php include "productosimgsinfo.php" ?>
<?php include "userfn50.php" ?>
<?php include "claveinfo.php" ?>
<?php
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT"); // Date in the past
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT"); // Always modified
header("Cache-Control: private, no-store, no-cache, must-revalidate"); // HTTP/1.1 
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache"); // HTTP/1.0
?>
<?php

// Open connection to the database
$conn = ew_Connect();
?>
<?php
$Security = new cAdvancedSecurity();
?>
<?php
if (!$Security->IsLoggedIn()) $Security->AutoLogin();
if (!$Security->IsLoggedIn()) {
	$Security->SaveLastUrl();
	Page_Terminate("login.php");
}
?>
<?php

// Common page loading event (in userfn*.php)
Page_Loading();
?>
<?php

// Page load event, used in current page
Page_Load();
?>
<?php
$productosimgs->Export = @$_GET["export"]; // Get export parameter
$sExport = $productosimgs->Export; // Get export parameter, used in header
$sExportFile = $productosimgs->TableVar; // Get export file, used in header
?>
<?php

// Load key from QueryString
if (@$_GET["id"] <> "") {
	$productosimgs->id->setQueryStringValue($_GET["id"]);
}

// Create form object
$objForm = new cFormObj();
if (@$_POST["a_edit"] <> "") {
	$productosimgs->CurrentAction = $_POST["a_edit"]; // Get action code
	GetUploadFiles(); // Get upload files
	LoadFormValues(); // Get form values
} else {
	$productosimgs->CurrentAction = "I"; // Default action is display
}

// Check if valid key
if ($productosimgs->id->CurrentValue == "") Page_Terminate($productosimgs->getReturnUrl()); // Invalid key, exit
switch ($productosimgs->CurrentAction) {
	case "I": // Get a record to display
		if (!LoadRow()) { // Load Record based on key
			$_SESSION[EW_SESSION_MESSAGE] = "No se han encontrado registros"; // No record found
			Page_Terminate($productosimgs->getReturnUrl()); // Return to caller
		}
		break;
	Case "U": // Update
		$productosimgs->SendEmail = TRUE; // Send email on update success
		if (EditRow()) { // Update Record based on key
			$_SESSION[EW_SESSION_MESSAGE] = "Actualizado correctamente!"; // Update success
			Page_Terminate($productosimgs->getReturnUrl()); // Return to caller
		} else {
			RestoreFormValues(); // Restore form values if update failed
		}
}

// Render the record
$productosimgs->RowType = EW_ROWTYPE_EDIT; // Render as edit
RenderRow();
?>
<?php include "header.php" ?>
<script type="text/javascript">
<!--
var EW_PAGE_ID = "edit"; // Page id

//-->
</script>
<script type="text/javascript">
<!--

function ew_ValidateForm(fobj) {
	if (fobj.a_confirm && fobj.a_confirm.value == "F")
		return true;
	var i, elm, aelm, infix;
	var rowcnt = (fobj.key_count) ? Number(fobj.key_count.value) : 1;
	for (i=0; i<rowcnt; i++) {
		infix = (fobj.key_count) ? String(i+1) : "";
		elm = fobj.elements["x" + infix + "_imagen"];
		if (elm && !ew_CheckFileType(elm.value)) { 
			if (!ew_OnError(elm, "Tipo de archivo no est� permitido.")) 
				return false; 
		}
	}
	return true;
}

//-->
</script>
<script type="text/javascript">
<!--

// js for DHtml Editor
//-->

</script>
<script type="text/javascript">
<!--

// js for Popup Calendar
//-->

</script>
<script type="text/javascript">
<!--
var ew_MultiPagePage = "Pagina"; // multi-page Page Text
var ew_MultiPageOf = "de"; // multi-page Of Text
var ew_MultiPagePrev = "Anterior"; // multi-page Prev Text
var ew_MultiPageNext = "Siguiente"; // multi-page Next Text

//-->
</script>
<script language="JavaScript" type="text/javascript">
<!--

// Write your client script here, no need to add script tags.
// To include another .js script, use:
// ew_ClientScriptInclude("my_javascript.js"); 
//-->

</script>
<p><span class="phpmaker">Editar TABLA: Productos Imgs<br><br><a href="<?php echo $productosimgs->getReturnUrl() ?>">volver</a></span></p>
<?php
if (@$_SESSION[EW_SESSION_MESSAGE] <> "") {
?>
<p><span class="ewmsg"><?php echo $_SESSION[EW_SESSION_MESSAGE] ?></span></p>
<?php
	$_SESSION[EW_SESSION_MESSAGE] = ""; // Clear message
}
?>
<form name="fproductosimgsedit" id="fproductosimgsedit" action="productosimgsedit.php" method="post" enctype="multipart/form-data" onSubmit="return ew_ValidateForm(this);">
<p>
<input type="hidden" name="a_edit" id="a_edit" value="U">
<table class="ewTable">
	<tr class="ewTableRow">
		<td class="ewTableHeader">id</td>
		<td<?php echo $productosimgs->id->CellAttributes() ?>><span id="cb_x_id">
<div<?php echo $productosimgs->id->ViewAttributes() ?>><?php echo $productosimgs->id->EditValue ?></div>
<input type="hidden" name="x_id" id="x_id" value="<?php echo ew_HtmlEncode($productosimgs->id->CurrentValue) ?>">
</span></td>
	</tr>
	<tr class="ewTableAltRow">
		<td class="ewTableHeader">producto</td>
		<td<?php echo $productosimgs->producto->CellAttributes() ?>><span id="cb_x_producto">
<select id="x_producto" name="x_producto"<?php echo $productosimgs->producto->EditAttributes() ?>>
<!--option value="">Seleccione</option-->
<?php
if (is_array($productosimgs->producto->EditValue)) {
	$arwrk = $productosimgs->producto->EditValue;
	$rowswrk = count($arwrk);
	for ($rowcntwrk = 0; $rowcntwrk < $rowswrk; $rowcntwrk++) {
		$selwrk = (strval($productosimgs->producto->CurrentValue) == strval($arwrk[$rowcntwrk][0])) ? " selected" : "";	
?>
<option value="<?php echo ew_HtmlEncode($arwrk[$rowcntwrk][0]) ?>"<?php echo $selwrk ?>>
<?php echo $arwrk[$rowcntwrk][1] ?>
</option>
<?php
			}
}
?>
</select>
</span></td>
	</tr>
	<tr class="ewTableRow">
		<td class="ewTableHeader">imagen</td>
		<td<?php echo $productosimgs->imagen->CellAttributes() ?>><span id="cb_x_imagen">
<?php if (!is_null($productosimgs->imagen->Upload->DbValue)) { ?>
<input type="radio" name="a_imagen" id="a_imagen" value="1" checked>Guardar&nbsp;
<input type="radio" name="a_imagen" id="a_imagen" value="2">Eliminar&nbsp;
<input type="radio" name="a_imagen" id="a_imagen" value="3">Reemplazar<br>
<?php } else { ?>
<input type="hidden" name="a_imagen" id="a_imagen" value="3">
<?php } ?>
<input type="file" name="x_imagen" id="x_imagen" title=""  size="30" onchange="if (this.form.a_imagen[2]) this.form.a_imagen[2].checked=true;"<?php echo $productosimgs->imagen->EditAttributes() ?>>
</span></td>
	</tr>
	<tr class="ewTableAltRow">
		<td class="ewTableHeader">titulo</td>
		<td<?php echo $productosimgs->titulo->CellAttributes() ?>><span id="cb_x_titulo">
<input type="text" name="x_titulo" id="x_titulo" title="" size="60" maxlength="100" value="<?php echo $productosimgs->titulo->EditValue ?>"<?php echo $productosimgs->titulo->EditAttributes() ?>>
</span></td>
	</tr>
</table>
<p>
<input type="submit" name="btnAction" id="btnAction" value="  Editar  ">
</form>
<script language="JavaScript" type="text/javascript">
<!--

// Write your table-specific startup script here
// document.write("page loaded");
//-->

</script>
<?php include "footer.php" ?>
<?php

// If control is passed here, simply terminate the page without redirect
Page_Terminate();

// -----------------------------------------------------------------
//  Subroutine Page_Terminate
//  - called when exit page
//  - clean up connection and objects
//  - if url specified, redirect to url, otherwise end response
function Page_Terminate($url = "") {
	global $conn;

	// Page unload event, used in current page
	Page_Unload();

	// Global page unloaded event (in userfn*.php)
	Page_Unloaded();

	 // Close Connection
	$conn->Close();

	// Go to url if specified
	if ($url <> "") {
		ob_end_clean();
		header("Location: $url");
	}
	exit();
}
?>
<?php

// Function Get upload files
function GetUploadFiles() {
	global $objForm, $productosimgs;

	// Get upload data
		if ($productosimgs->imagen->Upload->UploadFile()) {

			// No action required
		} else {
			echo $productosimgs->imagen->Upload->Message;
			exit();
		}
}
?>
<?php

// Load form values
function LoadFormValues() {

	// Load from form
	global $objForm, $productosimgs;
	$productosimgs->id->setFormValue($objForm->GetValue("x_id"));
	$productosimgs->producto->setFormValue($objForm->GetValue("x_producto"));
	$productosimgs->titulo->setFormValue($objForm->GetValue("x_titulo"));
}

// Restore form values
function RestoreFormValues() {
	global $productosimgs;
	$productosimgs->id->CurrentValue = $productosimgs->id->FormValue;
	$productosimgs->producto->CurrentValue = $productosimgs->producto->FormValue;
	$productosimgs->titulo->CurrentValue = $productosimgs->titulo->FormValue;
}
?>
<?php

// Load row based on key values
function LoadRow() {
	global $conn, $Security, $productosimgs;
	$sFilter = $productosimgs->SqlKeyFilter();
	if (!is_numeric($productosimgs->id->CurrentValue)) {
		return FALSE; // Invalid key, exit
	}
	$sFilter = str_replace("@id@", ew_AdjustSql($productosimgs->id->CurrentValue), $sFilter); // Replace key value

	// Call Row Selecting event
	$productosimgs->Row_Selecting($sFilter);

	// Load sql based on filter
	$productosimgs->CurrentFilter = $sFilter;
	$sSql = $productosimgs->SQL();
	if ($rs = $conn->Execute($sSql)) {
		if ($rs->EOF) {
			$LoadRow = FALSE;
		} else {
			$LoadRow = TRUE;
			$rs->MoveFirst();
			LoadRowValues($rs); // Load row values

			// Call Row Selected event
			$productosimgs->Row_Selected($rs);
		}
		$rs->Close();
	} else {
		$LoadRow = FALSE;
	}
	return $LoadRow;
}

// Load row values from recordset
function LoadRowValues(&$rs) {
	global $productosimgs;
	$productosimgs->id->setDbValue($rs->fields('id'));
	$productosimgs->producto->setDbValue($rs->fields('producto'));
	$productosimgs->imagen->Upload->DbValue = $rs->fields('imagen');
	$productosimgs->titulo->setDbValue($rs->fields('titulo'));
}
?>
<?php

// Render row values based on field settings
function RenderRow() {
	global $conn, $Security, $productosimgs;

	// Call Row Rendering event
	$productosimgs->Row_Rendering();

	// Common render codes for all row types
	// id

	$productosimgs->id->CellCssStyle = "";
	$productosimgs->id->CellCssClass = "";

	// producto
	$productosimgs->producto->CellCssStyle = "";
	$productosimgs->producto->CellCssClass = "";

	// imagen
	$productosimgs->imagen->CellCssStyle = "";
	$productosimgs->imagen->CellCssClass = "";

	// titulo
	$productosimgs->titulo->CellCssStyle = "";
	$productosimgs->titulo->CellCssClass = "";
	if ($productosimgs->RowType == EW_ROWTYPE_VIEW) { // View row
	} elseif ($productosimgs->RowType == EW_ROWTYPE_ADD) { // Add row
	} elseif ($productosimgs->RowType == EW_ROWTYPE_EDIT) { // Edit row

		// id
		$productosimgs->id->EditCustomAttributes = "";
		$productosimgs->id->EditValue = $productosimgs->id->CurrentValue;
		$productosimgs->id->CssStyle = "";
		$productosimgs->id->CssClass = "";
		$productosimgs->id->ViewCustomAttributes = "";

		// producto
		$productosimgs->producto->EditCustomAttributes = "";
		$sSqlWrk = "SELECT `id`, `producto` FROM `productos`";
		$rswrk = $conn->Execute($sSqlWrk);
		$arwrk = ($rswrk) ? $rswrk->GetRows() : array();
		if ($rswrk) $rswrk->Close();
		array_unshift($arwrk, array("", "Seleccione"));
		$productosimgs->producto->EditValue = $arwrk;

		// imagen
		$productosimgs->imagen->EditCustomAttributes = "";
		$productosimgs->imagen->EditValue = $productosimgs->imagen->CurrentValue;

		// titulo
		$productosimgs->titulo->EditCustomAttributes = "";
		$productosimgs->titulo->EditValue = ew_HtmlEncode($productosimgs->titulo->CurrentValue);
	} elseif ($productosimgs->RowType == EW_ROWTYPE_SEARCH) { // Search row
	}

	// Call Row Rendered event
	$productosimgs->Row_Rendered();
}
?>
<?php

// Update record based on key values
function EditRow() {
	global $conn, $Security, $productosimgs;
	$sFilter = $productosimgs->SqlKeyFilter();
	if (!is_numeric($productosimgs->id->CurrentValue)) {
		return FALSE;
	}
	$sFilter = str_replace("@id@", ew_AdjustSql($productosimgs->id->CurrentValue), $sFilter); // Replace key value
	$productosimgs->CurrentFilter = $sFilter;
	$sSql = $productosimgs->SQL();
	$conn->raiseErrorFn = 'ew_ErrorFn';
	$rs = $conn->Execute($sSql);
	$conn->raiseErrorFn = '';
	if ($rs === FALSE)
		return FALSE;
	if ($rs->EOF) {
		$EditRow = FALSE; // Update Failed
	} else {

		// Save old values
		$rsold =& $rs->fields;
		$rsnew = array();

		// Field id
		// Field producto

		$productosimgs->producto->SetDbValueDef($productosimgs->producto->CurrentValue, NULL);
		$rsnew['producto'] =& $productosimgs->producto->DbValue;

		// Field imagen
		$productosimgs->imagen->Upload->SaveToSession(); // Save file value to Session
		if ($productosimgs->imagen->Upload->Action == "2" || $productosimgs->imagen->Upload->Action == "3") { // Update/Remove
		$productosimgs->imagen->DbValue = $rs->fields('imagen'); // Get original value
		if (is_null($productosimgs->imagen->Upload->Value)) {
			$productosimgs->imagen->Upload->DbValue = NULL;
		} else {
			$productosimgs->imagen->Upload->DbValue = ew_UploadFileNameEx(ew_UploadPathEx(TRUE, "../imgs/"), $productosimgs->imagen->Upload->FileName);
		}
		$rsnew['imagen'] =& $productosimgs->imagen->Upload->DbValue;
		}

		// Field titulo
		$productosimgs->titulo->SetDbValueDef($productosimgs->titulo->CurrentValue, NULL);
		$rsnew['titulo'] =& $productosimgs->titulo->DbValue;

		// Call Row Updating event
		$bUpdateRow = $productosimgs->Row_Updating($rsold, $rsnew);
		if ($bUpdateRow) {

		// Field imagen
			if (!is_null($productosimgs->imagen->Upload->Value)) ew_SaveFile(ew_UploadPathEx(TRUE, "../imgs/"), $rsnew['imagen'], $productosimgs->imagen->Upload->Value);
			if ($productosimgs->imagen->DbValue <> "") @unlink(ew_UploadPathEx(TRUE, "../imgs/") . $productosimgs->imagen->DbValue);
			$conn->raiseErrorFn = 'ew_ErrorFn';
			$EditRow = $conn->Execute($productosimgs->UpdateSQL($rsnew));
			$conn->raiseErrorFn = '';
		} else {
			if ($productosimgs->CancelMessage <> "") {
				$_SESSION[EW_SESSION_MESSAGE] = $productosimgs->CancelMessage;
				$productosimgs->CancelMessage = "";
			} else {
				$_SESSION[EW_SESSION_MESSAGE] = "Actualizar cancelado!";
			}
			$EditRow = FALSE;
		}
	}

	// Call Row Updated event
	if ($EditRow) {
		$productosimgs->Row_Updated($rsold, $rsnew);
	}
	$rs->Close();

	// Field imagen
	$productosimgs->imagen->Upload->RemoveFromSession(); // Remove file value from Session
	return $EditRow;
}
?>
<?php

// Page Load event
function Page_Load() {

	//echo "Page Load";
}

// Page Unload event
function Page_Unload() {

	//echo "Page Unload";
}
?>
