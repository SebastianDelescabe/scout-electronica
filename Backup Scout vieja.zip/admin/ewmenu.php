<table width="100%" border="0" cellspacing="0" cellpadding="2">
<?php if (IsLoggedIn()) { ?>
	<tr><td><span class="phpmaker"><a href="clavelist.php?cmd=resetall">Clave</a></span></td></tr>
<?php } ?>
<?php if (IsLoggedIn()) { ?>
	<tr><td><span class="phpmaker"><a href="productoslist.php?cmd=resetall">Productos</a></span></td></tr>
<?php } ?>
<?php if (IsLoggedIn()) { ?>
	<tr><td><span class="phpmaker"><a href="productosimgslist.php?cmd=resetall">Productos Imgs</a></span></td></tr>
<?php } ?>
<?php if (IsLoggedIn()) { ?>
	<tr><td><span class="phpmaker"><a href="logout.php">Salir</a></span></td></tr>
<?php } elseif (substr(ew_ScriptName(), -1*strlen("login.php")) <> "login.php") { ?>
	<tr><td><span class="phpmaker"><a href="login.php">Login</a></span></td></tr>
<?php } ?>
</table>
