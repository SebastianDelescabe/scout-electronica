<?php
define("EW_PAGE_ID", "blobview", TRUE); // Page ID
?>
<?php 
session_start(); // Initialize session data
ob_start(); // Turn on output buffering
?>
<?php include "ewcfg50.php" ?>
<?php include "ewmysql50.php" ?>
<?php include "phpfn50.php" ?>
<?php include "productosimgsinfo.php" ?>
<?php include "claveinfo.php" ?>
<?php
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT"); // Date in the past
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT"); // Always modified
header("Cache-Control: private, no-store, no-cache, must-revalidate"); // HTTP/1.1 
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache"); // HTTP/1.0
?>
<?php

// Open connection to the database
$conn = ew_Connect();
?>
<?php
$Security = new cAdvancedSecurity();
?>
<?php
if (!$Security->IsLoggedIn()) $Security->AutoLogin();
if (!$Security->IsLoggedIn()) {
	$Security->SaveLastUrl();
	Page_Terminate("login.php");
}
?>
<?php

// Get key
if (@$_GET["id"] <> "") {
	$productosimgs->id->setQueryStringValue($_GET["id"]);
} else {
	Page_Terminate(); // Exit
}
$objBinary = new cUpload('productosimgs', 'x_imagen', TRUE);

// Show thumbnail
$bShowThumbnail = (@$_GET["showthumbnail"] == "1");
if (@$_GET["thumbnailwidth"] == "" && @$_GET["thumbnailheight"] == "") {
	$iThumbnailWidth = 100; // Set default width
	$iThumbnailHeight = 100; // Set default height
} else {
	if (@$_GET["thumbnailwidth"] <> "") {
		$iThumbnailWidth = $_GET["thumbnailwidth"];
		if (!is_numeric($iThumbnailWidth) || $iThumbnailWidth < 0) $iThumbnailWidth = 0;
	}
	if (@$_GET["thumbnailheight"] <> "") {
		$iThumbnailHeight = $_GET["thumbnailheight"];
		if (!is_numeric($iThumbnailHeight) || $iThumbnailHeight < 0) $iThumbnailHeight = 0;
	}
}
if (@$_GET["quality"] <> "") {
	$quality = $_GET["quality"];
	if (!is_numeric($quality)) $quality = 75; // Set Default
} else {
	$quality = 75;
}
$sFilter = $productosimgs->SqlKeyFilter();
if (!is_numeric($productosimgs->id->QueryStringValue)) {
	$sFilter = "0=1"; // Prevent sql injection
}
$sFilter = str_replace("@id@", ew_AdjustSql($productosimgs->id->CurrentValue), $sFilter);

// Set up filter (Sql Where Clause) and get Return Sql
// Sql constructor in productosimgs class, productosimgsinfo.php

$productosimgs->CurrentFilter = $sFilter;
$sSql = $productosimgs->SQL();
if ($rs = $conn->Execute($sSql)) {
	if (!$rs->EOF) {
		header("Content-type: images");
		if (trim(strval($rs->fields('imagen'))) <> "") {
			header("Content-Disposition: attachment; filename=" . $rs->fields('imagen'));
		}
		$objBinary->Value = $rs->fields('imagen');
		if ($bShowThumbnail) {
			ew_ResizeBinary($objBinary->Value, $iThumbnailWidth, $iThumbnailHeight, $quality);
		}
		echo $objBinary->Value;
	}
	$rs->Close();
}
?>
<?php

// If control is passed here, simply terminate the page without redirect
Page_Terminate();

// -----------------------------------------------------------------
//  Subroutine Page_Terminate
//  - called when exit page
//  - clean up connection and objects
//  - if url specified, redirect to url, otherwise end response
function Page_Terminate($url = "") {
	global $conn;

	 // Close Connection
	$conn->Close();

	// Go to url if specified
	if ($url <> "") {
		ob_end_clean();
		header("Location: $url");
	}
	exit();
}
?>
<?php
?>
