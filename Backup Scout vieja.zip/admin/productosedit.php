<?php
define("EW_PAGE_ID", "edit", TRUE); // Page ID
define("EW_TABLE_NAME", 'productos', TRUE);
?>
<?php 
session_start(); // Initialize session data
ob_start(); // Turn on output buffering
?>
<?php include "ewcfg50.php" ?>
<?php include "ewmysql50.php" ?>
<?php include "phpfn50.php" ?>
<?php include "productosinfo.php" ?>
<?php include "userfn50.php" ?>
<?php include "claveinfo.php" ?>
<?php
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT"); // Date in the past
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT"); // Always modified
header("Cache-Control: private, no-store, no-cache, must-revalidate"); // HTTP/1.1 
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache"); // HTTP/1.0
?>
<?php

// Open connection to the database
$conn = ew_Connect();
?>
<?php
$Security = new cAdvancedSecurity();
?>
<?php
if (!$Security->IsLoggedIn()) $Security->AutoLogin();
if (!$Security->IsLoggedIn()) {
	$Security->SaveLastUrl();
	Page_Terminate("login.php");
}
?>
<?php

// Common page loading event (in userfn*.php)
Page_Loading();
?>
<?php

// Page load event, used in current page
Page_Load();
?>
<?php
$productos->Export = @$_GET["export"]; // Get export parameter
$sExport = $productos->Export; // Get export parameter, used in header
$sExportFile = $productos->TableVar; // Get export file, used in header
?>
<?php

// Load key from QueryString
if (@$_GET["id"] <> "") {
	$productos->id->setQueryStringValue($_GET["id"]);
}

// Create form object
$objForm = new cFormObj();
if (@$_POST["a_edit"] <> "") {
	$productos->CurrentAction = $_POST["a_edit"]; // Get action code
	LoadFormValues(); // Get form values
} else {
	$productos->CurrentAction = "I"; // Default action is display
}

// Check if valid key
if ($productos->id->CurrentValue == "") Page_Terminate($productos->getReturnUrl()); // Invalid key, exit
switch ($productos->CurrentAction) {
	case "I": // Get a record to display
		if (!LoadRow()) { // Load Record based on key
			$_SESSION[EW_SESSION_MESSAGE] = "No se han encontrado registros"; // No record found
			Page_Terminate($productos->getReturnUrl()); // Return to caller
		}
		break;
	Case "U": // Update
		$productos->SendEmail = TRUE; // Send email on update success
		if (EditRow()) { // Update Record based on key
			$_SESSION[EW_SESSION_MESSAGE] = "Actualizado correctamente!"; // Update success
			Page_Terminate($productos->getReturnUrl()); // Return to caller
		} else {
			RestoreFormValues(); // Restore form values if update failed
		}
}

// Render the record
$productos->RowType = EW_ROWTYPE_EDIT; // Render as edit
RenderRow();
?>
<?php include "header.php" ?>
<script type="text/javascript">
<!--
var EW_PAGE_ID = "edit"; // Page id

//-->
</script>
<script type="text/javascript">
<!--

function ew_ValidateForm(fobj) {
	if (fobj.a_confirm && fobj.a_confirm.value == "F")
		return true;
	var i, elm, aelm, infix;
	var rowcnt = (fobj.key_count) ? Number(fobj.key_count.value) : 1;
	for (i=0; i<rowcnt; i++) {
		infix = (fobj.key_count) ? String(i+1) : "";
	}
	return true;
}

//-->
</script>
<script type="text/javascript">
<!--

// js for DHtml Editor
//-->

</script>
<script type="text/javascript">
<!--

// js for Popup Calendar
//-->

</script>
<script type="text/javascript">
<!--
var ew_MultiPagePage = "Pagina"; // multi-page Page Text
var ew_MultiPageOf = "de"; // multi-page Of Text
var ew_MultiPagePrev = "Anterior"; // multi-page Prev Text
var ew_MultiPageNext = "Siguiente"; // multi-page Next Text

//-->
</script>
<script language="JavaScript" type="text/javascript">
<!--

// Write your client script here, no need to add script tags.
// To include another .js script, use:
// ew_ClientScriptInclude("my_javascript.js"); 
//-->

</script>
<p><span class="phpmaker">Editar TABLA: Productos<br><br><a href="<?php echo $productos->getReturnUrl() ?>">volver</a></span></p>
<?php
if (@$_SESSION[EW_SESSION_MESSAGE] <> "") {
?>
<p><span class="ewmsg"><?php echo $_SESSION[EW_SESSION_MESSAGE] ?></span></p>
<?php
	$_SESSION[EW_SESSION_MESSAGE] = ""; // Clear message
}
?>
<form name="fproductosedit" id="fproductosedit" action="productosedit.php" method="post" onSubmit="return ew_ValidateForm(this);">
<p>
<input type="hidden" name="a_edit" id="a_edit" value="U">
<table class="ewTable">
	<tr class="ewTableRow">
		<td class="ewTableHeader">id</td>
		<td<?php echo $productos->id->CellAttributes() ?>><span id="cb_x_id">
<div<?php echo $productos->id->ViewAttributes() ?>><?php echo $productos->id->EditValue ?></div>
<input type="hidden" name="x_id" id="x_id" value="<?php echo ew_HtmlEncode($productos->id->CurrentValue) ?>">
</span></td>
	</tr>
	<tr class="ewTableAltRow">
		<td class="ewTableHeader">producto</td>
		<td<?php echo $productos->producto->CellAttributes() ?>><span id="cb_x_producto">
<input type="text" name="x_producto" id="x_producto" title="" size="60" maxlength="150" value="<?php echo $productos->producto->EditValue ?>"<?php echo $productos->producto->EditAttributes() ?>>
</span></td>
	</tr>
	<tr class="ewTableRow">
		<td class="ewTableHeader">descripcion</td>
		<td<?php echo $productos->descripcion->CellAttributes() ?>><span id="cb_x_descripcion">
<textarea name="x_descripcion" id="x_descripcion" style="width: 600px; height: 150px;" <?php echo $productos->descripcion->EditAttributes() ?>><?php echo $productos->descripcion->EditValue ?></textarea>
</span></td>
	</tr>
</table>
<p>
<input type="submit" name="btnAction" id="btnAction" value="  Editar  ">
</form>
<script language="JavaScript" type="text/javascript">
<!--

// Write your table-specific startup script here
// document.write("page loaded");
//-->

</script>
<?php include "footer.php" ?>
<?php

// If control is passed here, simply terminate the page without redirect
Page_Terminate();

// -----------------------------------------------------------------
//  Subroutine Page_Terminate
//  - called when exit page
//  - clean up connection and objects
//  - if url specified, redirect to url, otherwise end response
function Page_Terminate($url = "") {
	global $conn;

	// Page unload event, used in current page
	Page_Unload();

	// Global page unloaded event (in userfn*.php)
	Page_Unloaded();

	 // Close Connection
	$conn->Close();

	// Go to url if specified
	if ($url <> "") {
		ob_end_clean();
		header("Location: $url");
	}
	exit();
}
?>
<?php

// Load form values
function LoadFormValues() {

	// Load from form
	global $objForm, $productos;
	$productos->id->setFormValue($objForm->GetValue("x_id"));
	$productos->producto->setFormValue($objForm->GetValue("x_producto"));
	$productos->descripcion->setFormValue($objForm->GetValue("x_descripcion"));
}

// Restore form values
function RestoreFormValues() {
	global $productos;
	$productos->id->CurrentValue = $productos->id->FormValue;
	$productos->producto->CurrentValue = $productos->producto->FormValue;
	$productos->descripcion->CurrentValue = $productos->descripcion->FormValue;
}
?>
<?php

// Load row based on key values
function LoadRow() {
	global $conn, $Security, $productos;
	$sFilter = $productos->SqlKeyFilter();
	if (!is_numeric($productos->id->CurrentValue)) {
		return FALSE; // Invalid key, exit
	}
	$sFilter = str_replace("@id@", ew_AdjustSql($productos->id->CurrentValue), $sFilter); // Replace key value

	// Call Row Selecting event
	$productos->Row_Selecting($sFilter);

	// Load sql based on filter
	$productos->CurrentFilter = $sFilter;
	$sSql = $productos->SQL();
	if ($rs = $conn->Execute($sSql)) {
		if ($rs->EOF) {
			$LoadRow = FALSE;
		} else {
			$LoadRow = TRUE;
			$rs->MoveFirst();
			LoadRowValues($rs); // Load row values

			// Call Row Selected event
			$productos->Row_Selected($rs);
		}
		$rs->Close();
	} else {
		$LoadRow = FALSE;
	}
	return $LoadRow;
}

// Load row values from recordset
function LoadRowValues(&$rs) {
	global $productos;
	$productos->id->setDbValue($rs->fields('id'));
	$productos->producto->setDbValue($rs->fields('producto'));
	$productos->descripcion->setDbValue($rs->fields('descripcion'));
}
?>
<?php

// Render row values based on field settings
function RenderRow() {
	global $conn, $Security, $productos;

	// Call Row Rendering event
	$productos->Row_Rendering();

	// Common render codes for all row types
	// id

	$productos->id->CellCssStyle = "";
	$productos->id->CellCssClass = "";

	// producto
	$productos->producto->CellCssStyle = "";
	$productos->producto->CellCssClass = "";

	// descripcion
	$productos->descripcion->CellCssStyle = "";
	$productos->descripcion->CellCssClass = "";
	if ($productos->RowType == EW_ROWTYPE_VIEW) { // View row
	} elseif ($productos->RowType == EW_ROWTYPE_ADD) { // Add row
	} elseif ($productos->RowType == EW_ROWTYPE_EDIT) { // Edit row

		// id
		$productos->id->EditCustomAttributes = "";
		$productos->id->EditValue = $productos->id->CurrentValue;
		$productos->id->CssStyle = "";
		$productos->id->CssClass = "";
		$productos->id->ViewCustomAttributes = "";

		// producto
		$productos->producto->EditCustomAttributes = "";
		$productos->producto->EditValue = ew_HtmlEncode($productos->producto->CurrentValue);

		// descripcion
		$productos->descripcion->EditCustomAttributes = "";
		$productos->descripcion->EditValue = ew_HtmlEncode($productos->descripcion->CurrentValue);
	} elseif ($productos->RowType == EW_ROWTYPE_SEARCH) { // Search row
	}

	// Call Row Rendered event
	$productos->Row_Rendered();
}
?>
<?php

// Update record based on key values
function EditRow() {
	global $conn, $Security, $productos;
	$sFilter = $productos->SqlKeyFilter();
	if (!is_numeric($productos->id->CurrentValue)) {
		return FALSE;
	}
	$sFilter = str_replace("@id@", ew_AdjustSql($productos->id->CurrentValue), $sFilter); // Replace key value
	$productos->CurrentFilter = $sFilter;
	$sSql = $productos->SQL();
	$conn->raiseErrorFn = 'ew_ErrorFn';
	$rs = $conn->Execute($sSql);
	$conn->raiseErrorFn = '';
	if ($rs === FALSE)
		return FALSE;
	if ($rs->EOF) {
		$EditRow = FALSE; // Update Failed
	} else {

		// Save old values
		$rsold =& $rs->fields;
		$rsnew = array();

		// Field id
		// Field producto

		$productos->producto->SetDbValueDef($productos->producto->CurrentValue, NULL);
		$rsnew['producto'] =& $productos->producto->DbValue;

		// Field descripcion
		$productos->descripcion->SetDbValueDef($productos->descripcion->CurrentValue, NULL);
		$rsnew['descripcion'] =& $productos->descripcion->DbValue;

		// Call Row Updating event
		$bUpdateRow = $productos->Row_Updating($rsold, $rsnew);
		if ($bUpdateRow) {
			$conn->raiseErrorFn = 'ew_ErrorFn';
			$EditRow = $conn->Execute($productos->UpdateSQL($rsnew));
			$conn->raiseErrorFn = '';
		} else {
			if ($productos->CancelMessage <> "") {
				$_SESSION[EW_SESSION_MESSAGE] = $productos->CancelMessage;
				$productos->CancelMessage = "";
			} else {
				$_SESSION[EW_SESSION_MESSAGE] = "Actualizar cancelado!";
			}
			$EditRow = FALSE;
		}
	}

	// Call Row Updated event
	if ($EditRow) {
		$productos->Row_Updated($rsold, $rsnew);
	}
	$rs->Close();
	return $EditRow;
}
?>
<?php

// Page Load event
function Page_Load() {

	//echo "Page Load";
}

// Page Unload event
function Page_Unload() {

	//echo "Page Unload";
}
?>
