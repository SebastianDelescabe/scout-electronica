<?php
define("EW_PAGE_ID", "add", TRUE); // Page ID
define("EW_TABLE_NAME", 'productos', TRUE);
?>
<?php 
session_start(); // Initialize session data
ob_start(); // Turn on output buffering
?>
<?php include "ewcfg50.php" ?>
<?php include "ewmysql50.php" ?>
<?php include "phpfn50.php" ?>
<?php include "productosinfo.php" ?>
<?php include "userfn50.php" ?>
<?php include "claveinfo.php" ?>
<?php
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT"); // Date in the past
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT"); // Always modified
header("Cache-Control: private, no-store, no-cache, must-revalidate"); // HTTP/1.1 
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache"); // HTTP/1.0
?>
<?php

// Open connection to the database
$conn = ew_Connect();
?>
<?php
$Security = new cAdvancedSecurity();
?>
<?php
if (!$Security->IsLoggedIn()) $Security->AutoLogin();
if (!$Security->IsLoggedIn()) {
	$Security->SaveLastUrl();
	Page_Terminate("login.php");
}
?>
<?php

// Common page loading event (in userfn*.php)
Page_Loading();
?>
<?php

// Page load event, used in current page
Page_Load();
?>
<?php
$productos->Export = @$_GET["export"]; // Get export parameter
$sExport = $productos->Export; // Get export parameter, used in header
$sExportFile = $productos->TableVar; // Get export file, used in header
?>
<?php

// Load key values from QueryString
$bCopy = TRUE;
if (@$_GET["id"] != "") {
  $productos->id->setQueryStringValue($_GET["id"]);
} else {
  $bCopy = FALSE;
}

// Create form object
$objForm = new cFormObj();

// Process form if post back
if (@$_POST["a_add"] <> "") {
  $productos->CurrentAction = $_POST["a_add"]; // Get form action
  LoadFormValues(); // Load form values
} else { // Not post back
  if ($bCopy) {
    $productos->CurrentAction = "C"; // Copy Record
  } else {
    $productos->CurrentAction = "I"; // Display Blank Record
    LoadDefaultValues(); // Load default values
  }
}

// Perform action based on action code
switch ($productos->CurrentAction) {
  case "I": // Blank record, no action required
		break;
  case "C": // Copy an existing record
   if (!LoadRow()) { // Load record based on key
      $_SESSION[EW_SESSION_MESSAGE] = "No se han encontrado registros"; // No record found
      Page_Terminate($productos->getReturnUrl()); // Clean up and return
    }
		break;
  case "A": // ' Add new record
		$productos->SendEmail = TRUE; // Send email on add success
    if (AddRow()) { // Add successful
      $_SESSION[EW_SESSION_MESSAGE] = "Agregado correctamente!"; // Set up success message
      Page_Terminate($productos->KeyUrl($productos->getReturnUrl())); // Clean up and return
    } else {
      RestoreFormValues(); // Add failed, restore form values
    }
}

// Render row based on row type
$productos->RowType = EW_ROWTYPE_ADD;  // Render add type
RenderRow();
?>
<?php include "header.php" ?>
<script type="text/javascript">
<!--
var EW_PAGE_ID = "add"; // Page id

//-->
</script>
<script type="text/javascript">
<!--

function ew_ValidateForm(fobj) {
	if (fobj.a_confirm && fobj.a_confirm.value == "F")
		return true;
	var i, elm, aelm, infix;
	var rowcnt = (fobj.key_count) ? Number(fobj.key_count.value) : 1;
	for (i=0; i<rowcnt; i++) {
		infix = (fobj.key_count) ? String(i+1) : "";
	}
	return true;
}

//-->
</script>
<script type="text/javascript">
<!--

// js for DHtml Editor
//-->

</script>
<script type="text/javascript">
<!--

// js for Popup Calendar
//-->

</script>
<script type="text/javascript">
<!--
var ew_MultiPagePage = "Pagina"; // multi-page Page Text
var ew_MultiPageOf = "de"; // multi-page Of Text
var ew_MultiPagePrev = "Anterior"; // multi-page Prev Text
var ew_MultiPageNext = "Siguiente"; // multi-page Next Text

//-->
</script>
<script language="JavaScript" type="text/javascript">
<!--

// Write your client script here, no need to add script tags.
// To include another .js script, use:
// ew_ClientScriptInclude("my_javascript.js"); 
//-->

</script>
<p><span class="phpmaker">Agregar a TABLA: Productos<br><br><a href="<?php echo $productos->getReturnUrl() ?>">volver</a></span></p>
<?php
if (@$_SESSION[EW_SESSION_MESSAGE] <> "") { // Mesasge in Session, display
?>
<p><span class="ewmsg"><?php echo $_SESSION[EW_SESSION_MESSAGE] ?></span></p>
<?php
  $_SESSION[EW_SESSION_MESSAGE] = ""; // Clear message in Session
}
?>
<form name="fproductosadd" id="fproductosadd" action="productosadd.php" method="post" onSubmit="return ew_ValidateForm(this);">
<p>
<input type="hidden" name="a_add" id="a_add" value="A">
<table class="ewTable">
  <tr class="ewTableRow">
    <td class="ewTableHeader">producto</td>
    <td<?php echo $productos->producto->CellAttributes() ?>><span id="cb_x_producto">
<input type="text" name="x_producto" id="x_producto" title="" size="60" maxlength="150" value="<?php echo $productos->producto->EditValue ?>"<?php echo $productos->producto->EditAttributes() ?>>
</span></td>
  </tr>
  <tr class="ewTableAltRow">
    <td class="ewTableHeader">descripcion</td>
    <td<?php echo $productos->descripcion->CellAttributes() ?>><span id="cb_x_descripcion">
<textarea name="x_descripcion" id="x_descripcion" style="width: 600px; height: 150px;" <?php echo $productos->descripcion->EditAttributes() ?>><?php echo $productos->descripcion->EditValue ?></textarea>
</span></td>
  </tr>
</table>
<p>
<input type="submit" name="btnAction" id="btnAction" value="  Agregar  ">
</form>
<script language="JavaScript" type="text/javascript">
<!--

// Write your table-specific startup script here
// document.write("page loaded");
//-->

</script>
<?php include "footer.php" ?>
<?php

// If control is passed here, simply terminate the page without redirect
Page_Terminate();

// -----------------------------------------------------------------
//  Subroutine Page_Terminate
//  - called when exit page
//  - clean up connection and objects
//  - if url specified, redirect to url, otherwise end response
function Page_Terminate($url = "") {
	global $conn;

	// Page unload event, used in current page
	Page_Unload();

	// Global page unloaded event (in userfn*.php)
	Page_Unloaded();

	 // Close Connection
	$conn->Close();

	// Go to url if specified
	if ($url <> "") {
		ob_end_clean();
		header("Location: $url");
	}
	exit();
}
?>
<?php

// Load default values
function LoadDefaultValues() {
	global $productos;
}
?>
<?php

// Load form values
function LoadFormValues() {

	// Load from form
	global $objForm, $productos;
	$productos->producto->setFormValue($objForm->GetValue("x_producto"));
	$productos->descripcion->setFormValue($objForm->GetValue("x_descripcion"));
}

// Restore form values
function RestoreFormValues() {
	global $productos;
	$productos->producto->CurrentValue = $productos->producto->FormValue;
	$productos->descripcion->CurrentValue = $productos->descripcion->FormValue;
}
?>
<?php

// Load row based on key values
function LoadRow() {
	global $conn, $Security, $productos;
	$sFilter = $productos->SqlKeyFilter();
	if (!is_numeric($productos->id->CurrentValue)) {
		return FALSE; // Invalid key, exit
	}
	$sFilter = str_replace("@id@", ew_AdjustSql($productos->id->CurrentValue), $sFilter); // Replace key value

	// Call Row Selecting event
	$productos->Row_Selecting($sFilter);

	// Load sql based on filter
	$productos->CurrentFilter = $sFilter;
	$sSql = $productos->SQL();
	if ($rs = $conn->Execute($sSql)) {
		if ($rs->EOF) {
			$LoadRow = FALSE;
		} else {
			$LoadRow = TRUE;
			$rs->MoveFirst();
			LoadRowValues($rs); // Load row values

			// Call Row Selected event
			$productos->Row_Selected($rs);
		}
		$rs->Close();
	} else {
		$LoadRow = FALSE;
	}
	return $LoadRow;
}

// Load row values from recordset
function LoadRowValues(&$rs) {
	global $productos;
	$productos->id->setDbValue($rs->fields('id'));
	$productos->producto->setDbValue($rs->fields('producto'));
	$productos->descripcion->setDbValue($rs->fields('descripcion'));
}
?>
<?php

// Render row values based on field settings
function RenderRow() {
	global $conn, $Security, $productos;

	// Call Row Rendering event
	$productos->Row_Rendering();

	// Common render codes for all row types
	// producto

	$productos->producto->CellCssStyle = "";
	$productos->producto->CellCssClass = "";

	// descripcion
	$productos->descripcion->CellCssStyle = "";
	$productos->descripcion->CellCssClass = "";
	if ($productos->RowType == EW_ROWTYPE_VIEW) { // View row
	} elseif ($productos->RowType == EW_ROWTYPE_ADD) { // Add row

		// producto
		$productos->producto->EditCustomAttributes = "";
		$productos->producto->EditValue = ew_HtmlEncode($productos->producto->CurrentValue);

		// descripcion
		$productos->descripcion->EditCustomAttributes = "";
		$productos->descripcion->EditValue = ew_HtmlEncode($productos->descripcion->CurrentValue);
	} elseif ($productos->RowType == EW_ROWTYPE_EDIT) { // Edit row
	} elseif ($productos->RowType == EW_ROWTYPE_SEARCH) { // Search row
	}

	// Call Row Rendered event
	$productos->Row_Rendered();
}
?>
<?php

// Add record
function AddRow() {
	global $conn, $Security, $productos;

	// Check for duplicate key
	$bCheckKey = TRUE;
	$sFilter = $productos->SqlKeyFilter();
	if (trim(strval($productos->id->CurrentValue)) == "") {
		$bCheckKey = FALSE;
	} else {
		$sFilter = str_replace("@id@", ew_AdjustSql($productos->id->CurrentValue), $sFilter); // Replace key value
	}
	if (!is_numeric($productos->id->CurrentValue)) {
		$bCheckKey = FALSE;
	}
	if ($bCheckKey) {
		$rsChk = $productos->LoadRs($sFilter);
		if ($rsChk && !$rsChk->EOF) {
			$_SESSION[EW_SESSION_MESSAGE] = "Duplicar el valor de clave primaria";
			$rsChk->Close();
			return FALSE;
		}
	}
	$rsnew = array();

	// Field producto
	$productos->producto->SetDbValueDef($productos->producto->CurrentValue, NULL);
	$rsnew['producto'] =& $productos->producto->DbValue;

	// Field descripcion
	$productos->descripcion->SetDbValueDef($productos->descripcion->CurrentValue, NULL);
	$rsnew['descripcion'] =& $productos->descripcion->DbValue;

	// Call Row Inserting event
	$bInsertRow = $productos->Row_Inserting($rsnew);
	if ($bInsertRow) {
		$conn->raiseErrorFn = 'ew_ErrorFn';
		$AddRow = $conn->Execute($productos->InsertSQL($rsnew));
		$conn->raiseErrorFn = '';
	} else {
		if ($productos->CancelMessage <> "") {
			$_SESSION[EW_SESSION_MESSAGE] = $productos->CancelMessage;
			$productos->CancelMessage = "";
		} else {
			$_SESSION[EW_SESSION_MESSAGE] = "Insert cancelled";
		}
		$AddRow = FALSE;
	}
	if ($AddRow) {
		$productos->id->setDbValue($conn->Insert_ID());
		$rsnew['id'] =& $productos->id->DbValue;

		// Call Row Inserted event
		$productos->Row_Inserted($rsnew);
	}
	return $AddRow;
}
?>
<?php

// Page Load event
function Page_Load() {

	//echo "Page Load";
}

// Page Unload event
function Page_Unload() {

	//echo "Page Unload";
}
?>
