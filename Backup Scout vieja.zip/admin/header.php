<html>
<head>
	<title></title>
<link href="scout.css" rel="stylesheet" type="text/css" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="generator" content="PHPMaker v5.0.0.1" />

<!-- mobile Specific Metas -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"/>
<meta names="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-capable" content="yes" />
<meta name="format-detection" content="telephone=no">


</head>
<body>

<script type="text/javascript" src="nicEdit.js"></script>
<script type="text/javascript">
	bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });
</script>


<script type="text/javascript">
<!--
var EW_DATE_SEPARATOR; // Default date separator
EW_DATE_SEPARATOR = "/";
if (EW_DATE_SEPARATOR == '') EW_DATE_SEPARATOR = '/';
EW_UPLOAD_ALLOWED_FILE_EXT = "gif,jpg,jpeg,bmp,png,doc,xls,pdf,zip"; // Allowed upload file extension
var EW_FIELD_SEP = ', '; // Default field separator
var EW_TABLE_CLASSNAME = "ewTable"; // Note: changed the class name as needed

// Ajax settings
EW_LOOKUP_FILE_NAME = "ewlookup50.php"; // lookup file name
EW_ADD_OPTION_FILE_NAME = "ewaddopt50.php"; // add option file name

// Auto suggest settings
var EW_AST_SELECT_LIST_ITEM = 0;
var EW_AST_TEXT_BOX_ID;
var EW_AST_CANCEL_SUBMIT;
var EW_AST_OLD_TEXT_BOX_VALUE = "";
var EW_AST_MAX_NEW_VALUE_LENGTH = 5; // Only get data if value length <= this setting

// Multipage settings
var ew_PageIndex = 0;
var ew_MaxPageIndex = 0;
var ew_MinPageIndex = 0;
var ew_MultiPageElements = new Array();

//-->
</script>
<script type="text/javascript" src="ewp50.js"></script>
<script type="text/javascript" src="userfn50.js"></script>
<script language="JavaScript" type="text/javascript">
<!--

// Write your client script here, no need to add script tags.
// To include another .js script, use:
// ew_ClientScriptInclude("my_javascript.js");
//-->

</script>
<table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0">
	<!-- header (begin) -->
	<tr class="ewHeaderRow"><!-- *** Note: Only licensed users are allowed to change the logo *** -->
		<td height="50"><img src="407aaa.jpg" alt="" border="0"></td>
	</tr>
	<!-- header (end) -->
	<!-- content (begin) -->
	<tr>
		<td height="100%" valign="top">
<table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<!-- left column (begin) -->
		<td valign="top" class="ewMenuColumn">
<?php include "ewmenu.php" ?>
			<table height="100%" border="0" cellspacing="0" cellpadding="0">
				<tr><td class="ewMenuColumn"><!-- Area below Left Nav -->&nbsp;</td></tr> 
			</table> 
		</td>
		<!-- left column (end) -->
		<!-- right column (begin) -->
		<td valign="top" class="ewContentColumn">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr><td><span class="phpmaker"><b></b></span></td></tr>
</table>
