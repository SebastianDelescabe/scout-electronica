			<p>&nbsp;</p>
		</td>
		<!-- right column (end) -->
	</tr>
</table>
		</td>
	</tr>
<!-- content (end) -->
<!-- footer (begin) -->
	<tr>
		<td>
<table width="100%" border="0" cellspacing="0" cellpadding="4">
	<tr class="ewFooterRow">
		<td>&nbsp;<!-- *** Note: Only licensed users are allowed to remove or change the following copyright statement. *** -->
	<font class="ewFooterText">.....</font>
	<!-- Place other links, for example, disclaimer, here -->
		</td>
	</tr>
</table>
		</td>
	</tr>
<!-- footer (end) -->
</table>
<script language="JavaScript" type="text/javascript">
<!--

// Write your global startup script here
// document.write("page loaded");
//-->

</script>
</body>
</html>
