<!DOCTYPE HTML>

<html lang="es">

	<head>
	
		<meta name="keywords" content="laboratorio,medicinal,veterinario,durómetro,friabilómetro,desintegrador,disolutor,titulador,peristáltica,balanza,dosificadora,pouchera,blistera,calibración,certificación,automatización,reparación" />
		<meta name="description" content="Scout, fabricación equipos para control de calidad de comprimidos y dosificacion de polvos y líquidos." />
		<meta name="author" content="http://www.mamiaro.com" />
		
		<title>:: www.scout-e.com.ar ::</title>
		
		<!-- metatags -->
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		
		<!-- favicon -->
		<link rel="shortcut icon" type="image/x-icon" href="favicon.ico"/>
		
		<!-- mobile Specific Metas -->
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"/>
		<meta names="apple-mobile-web-app-status-bar-style" content="black-translucent">
		<meta name="apple-mobile-web-app-capable" content="yes" />
		<meta name="format-detection" content="telephone=no">
		
		<!-- Styles -->
		<link rel="stylesheet" type="text/css" href="reset.css" />
		<link rel="stylesheet" type="text/css" href="main.css" />
		<link rel="stylesheet" type="text/css" href="animate.css" />
		<link href='http://fonts.googleapis.com/css?family=PT+Sans+Narrow:400,700' rel='stylesheet' type='text/css'>
		
		<!-- Javascript -->
		<script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
		
		<!-- Fancy -->
	
		<!-- Add fancyBox main JS and CSS files -->
		<script type="text/javascript" src="fancybox/jquery.fancybox.js?v=2.1.5"></script>
		<link rel="stylesheet" type="text/css" href="fancybox/jquery.fancybox.css?v=2.1.5" media="screen" />
	
		<!-- Add Button helper (this is optional) -->
		<link rel="stylesheet" type="text/css" href="fancybox/helpers/jquery.fancybox-buttons.css?v=1.0.5" />
		<script type="text/javascript" src="fancybox/helpers/jquery.fancybox-buttons.js?v=1.0.5"></script>
	
		<!-- Add Thumbnail helper (this is optional) -->
		<link rel="stylesheet" type="text/css" href="fancybox/helpers/jquery.fancybox-thumbs.css?v=1.0.7" />
		<script type="text/javascript" src="fancybox/helpers/jquery.fancybox-thumbs.js?v=1.0.7"></script>
	
		<!-- Add Media helper (this is optional) -->
		<script type="text/javascript" src="fancybox/helpers/jquery.fancybox-media.js?v=1.0.6"></script>
		
		<script type="text/javascript">
				$(document).ready(function() {
		
				/*
				 *  Button helper. Disable animations, hide close button, change title type and content
				 */
	
				$('.fancybox-buttons').fancybox({
				    padding: 0,
					openEffect  : 'elastic',
					closeEffect : '100',
					prevEffect : 'fade',
					nextEffect : 'fade',
					closeBtn  : false,
	
					helpers : {
						overlay : {
						            css : {
						                'background' : 'rgba(0, 0, 0, 0.80)'
						            }
						        },
					
						title : {
							type : 'outside'
						},
						buttons	: {}
					},
	
					afterLoad : function() {
						this.title = 'Image ' + (this.index + 1) + ' of ' + this.group.length + (this.title ? ' - ' + this.title : '');
					}
				});
	

			});
		</script>
		<!-- /Fancy -->
		
		<!-- FlexSlider-->
		<link rel="stylesheet" href="flexslider.css" type="text/css">
		<script type="text/javascript"  src="js/jquery.flexslider.js"></script>
		
		<script type="text/javascript">
		  $(window).load(function() {
		    $('.flexslider').flexslider({
		      animation: "fade", // fade - slide
		      easing: "swing",
		      direction: "vertical", // vertical - horizontal
		      slideshow: true, 
		      slideshowSpeed: 3000,
		      animationSpeed: 1500,
		      randomize: true, 
		      pauseOnHover: true,
		      touch: false,
		      controlNav: false, // puntitos
		      directionNav: false, // flechas
		      keyboard: true
		    });
		  });
		</script>
	
		<!-- /FlexSlider-->
		
		
		<script type="text/javascript" src="js/functions.js"></script>
		
		<!--[if lt IE 9]><script src="js/html5shiv.js"></script><![endif]-->
		

	
	</head>

	<body>
	<div class="franja animated fadeIn"></div>
		
		<!--container-->
		<div id="container">
		
		<!--caja 2 Menú-->
		<div class="full_box animated fadeIn s1 sombra" id="caja_dos">
			<div class="center_box">
			
				<div class="menu">
				<ul>
				        <li><a alt="" class="transition-background" href="index.php">Quienes Somos</a></li>
				        <li><a alt="" class="active" href="productos.php">Productos</a></li>
				        <li><a alt="" class="transition-background" href="servicios.php">Servicios</a></li>
				        <li><a alt="" class="transition-background" href="contacto.php">Contáctenos</a></li>
				</ul>
				</div>
			
			</div>
		</div>
		<!--/caja 2 Menú-->
		
			
			
			<!--caja 1 Header-->
			<div class="full_box" id="caja_uno">
				<div class="center_box sombra">
				
					<div class="header-izq animated flipInX s1"></div>
					
					<div class="header-der animated flipInX">
						<ul>
							<li><b class="turquesa">Dirección</b> Calle 11 de Setiembre Nº 6117 - Villa Ballester (1653) - Provincia de Bs As</li>
							<li><b class="turquesa">Tel-Fax</b> (5411) 4720 - 5603</li>
							<li><b class="turquesa">Email</b> <a class="email transition-color" alt="Email" href="mailto:scout-e@scout-e.com.ar?subject=Contacto con Scout-e">scout-e@scout-e.com.ar</a></li>
						</ul>
					</div>
					
					<div class="clear"></div>
				
				</div>
			</div>
			<!--/caja 1 Header-->
			
			
			<!--caja 3 Contenido-->
			<div class="full_box animated fadeInUp" id="caja_tres">
				<div class="center_box sombra">
				
					<div class="contenido">
					
					<div class="contenido-textos">
						<h1 class="titulos"><span class="ico-entypo-titulos">&#xf0da;</span> Productos</h1>
						<div id="clear"></div>
						
						<div class="textos">
							<ul>
							
<?php
require("conect.php");
$sql = mysql_query('SELECT * FROM productos ORDER BY id',$conexion) or die ('<b>MySQL Error:</b><br />'.mysql_error()); 
?>

<?php 
if( mysql_num_rows( $sql ) > 0 ){
while( $dato = mysql_fetch_array( $sql ) ){ 
?> 
							
								<a alt="" href="productos-imgs.php?id=<?=$dato['id']?>">
								<li class="item transition-background">
								<span class="ico-entypo-items">&#xf105;</span> <?php echo $dato['producto']; ?></li>
								</a>


<?php }
} ?> 
							</ul>
						</div>
					
					</div>
					
					<div class="tres-slides">
					
								<div class="contenido-img">
									<div class="flexslider">
									<ul class="slides">
									<a title="Scout-e" class="fancybox-buttons" data-fancybox-group="button" href="imgs/scout-07.jpg"><img class="animated fadeIn s1" src="imgs/scout-07-t.jpg" /></a>
									</ul>
									</div>
								</div>
								
								<div class="contenido-img">
									<div class="flexslider">
									<ul class="slides">
									<a title="Scout-e" class="fancybox-buttons" data-fancybox-group="button" href="imgs/scout-08.jpg"><img class="animated fadeIn s2" src="imgs/scout-08-t.jpg" /></a>
									</ul>
									</div>
								</div>
								
								<div class="contenido-img">
									<div class="flexslider">
									<ul class="slides">
									<a title="Scout-e" class="fancybox-buttons" data-fancybox-group="button" href="imgs/scout-09.jpg"><img class="animated fadeIn s3" src="imgs/scout-09-t.jpg" /></a>
									</ul>
									</div>
								</div>
																			
					</div>
					
					<div class="clear"></div>
					
					
					
					
					</div>
				
				</div>
			</div>
			<!--/caja 3 Contenido-->
			
			<!--caja 4 Pie-->
			<div class="full_box" id="caja_cuatro">
				<div class="center_box">
				
					<div class="pie">
					
							<div class="pie-der animated fadeInRight s1">
								<a alt="Twitter" target="_blank" href="#">
								<span class="ico-entypo-social transition-color">&#xf099;</span>
								</a>
								
								<a alt="Facebook" target="_blank" href="#">
								<span class="ico-entypo-social transition-color">&#xf082;</span>
								</a>
								
								<a alt="Email" href="mailto:mailto:scout-e@scout-e.com.ar?subject=Contacto con Scout-e">
								<span class="ico-entypo-social transition-color">&#xf1d8;</span>
								</a>
							</div>
							
							<div class="pie-izq animated fadeInLeft s1">
							<a alt="Diseño" target="_blank" href="http://www.mamiaro.com"><span class="ico-entypo-social transition-color">&#xf013;</span></a>
							</div>
							
							<div class="clear"></div>
					
					</div>
				
				</div>
			</div>
			<!--/caja 4 Pie-->
			
			
			

			
			
			
			<!-- Fancy 
			<a title="Título..." class="fancybox-buttons" data-fancybox-group="button" href="imgs/1.jpg">
			<img class="" alt="Imagen" border="0" src="imgs/1.jpg"/>
			</a>
			-->
			
			
			
			
			
	
						
		</div>
		<!--/container-->
		
	</body>

</html>

