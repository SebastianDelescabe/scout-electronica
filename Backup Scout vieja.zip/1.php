<?
//$adminaddress = "info@mamiaro.com.ar";
$adminaddress = "scout-e@scout-e.com.ar";
$siteaddress ="http://www.scout-e.com.ar";
$sitename = "scout-e.com.ar";
$date = date("m/d/Y H:i:s");

if ($REMOTE_ADDR == "") $ip = "no ip";
else $ip = getHostByAddr($REMOTE_ADDR);

IF ($action != ""):
mail("$adminaddress","||| Contacto desde la Web |||",
"Empresa: $empresa
Contacto: $contacto
Email: $email
Tel�fono: $telefono
Provincia: $provincia
Pa�s: $pais\n

El visitante nos comenta:
..................
$consulta
..................

Logged Info :
..................
Using: $HTTP_USER_AGENT
Hostname: $ip
IP address: $REMOTE_ADDR
Date/Time:  $date","FROM:$adminaddress");

mail("$email","Muchas gracias por visitarnos. $sitename", "Hola $contacto,\n
Le agradecemos el interes por nuestros productos y servicios,\n
a la brevedad nos conectaremos con Usted.\n
Gracias.
..................
Empresa: $empresa
Contacto: $contacto
Email: $email
Tel�fono: $telefono
Provincia: $provincia
Pa�s: $pais\n

El visitante nos comenta:
..................
$consulta
..................



$siteaddress","FROM:$adminaddress");


ENDIF;
?>
